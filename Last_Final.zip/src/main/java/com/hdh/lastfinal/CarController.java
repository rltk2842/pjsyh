package com.hdh.lastfinal;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.hdh.lastfinal.bean.CarSelInfo;
import com.hdh.lastfinal.service.CarManagement;



@Controller
public class CarController {
	ModelAndView mav;

	@Autowired
	CarManagement cam;

	@RequestMapping(value = "/KCarMain")
	public ModelAndView home(Integer pageNum) {
		mav = new ModelAndView();
		mav = cam.getCarKoreaList(pageNum);
		//mav = cam.getCarListK("국산");
		return mav;
	}
	
	@RequestMapping(value = "/SCarMain", method = RequestMethod.GET)
	public ModelAndView homee() {
		mav = cam.getCarListS("수입");
		return mav;
	}

	@RequestMapping(value = "/carInfo")
	public ModelAndView carInfo(Integer pageNum) {
		mav = cam.getCarhomeList(pageNum);			
		return mav;
	}


	@RequestMapping(value = "/home")
	public String homee2() {	

		return "home";
	}
	
	@RequestMapping(value = "/purchase")
	public String purchase() {	

		return "purchase";
	}

	@RequestMapping(value = "/carList")
	public @ResponseBody List<String> carList(@RequestParam("comp") String comp){
		List<String> cList = cam.getCarNameList(comp);
		System.out.println("CarList");
		return cList;
	}

	@RequestMapping(value = "/carYear")
	public @ResponseBody List<String> yearList(@RequestParam("name") String name){
		List<String> yList = cam.getCarYearList(name);

		return yList;
	}
	
	@RequestMapping(value = "/carSearch", method = RequestMethod.POST)
	public @ResponseBody List<CarSelInfo> carSearch(CarSelInfo csel){
		List<CarSelInfo> csList = cam.getCarSelList(csel, "국산");
		
		return csList;
	}
	
	@RequestMapping(value = "/carRevers", method = RequestMethod.POST)
	public @ResponseBody List<CarSelInfo> carRevers(CarSelInfo csel){
		List<CarSelInfo> crList = cam.getCarReList(csel, "국산");
		
		return crList;
	}
	
	@RequestMapping(value = "/carContent")
	public ModelAndView carContent(@RequestParam("ktc_num") String ktc_num) {
		int ktcNum = Integer.parseInt(ktc_num);
		mav = cam.getCarContent(ktcNum);
		
		return mav;
	}
	
	@RequestMapping(value = "/carConList")
	public ModelAndView carConList(@RequestParam("ktc_number") String ktc_number) {
		
		System.out.println("이런"+ktc_number);
		mav = cam.getCarUpdate(ktc_number);
		
		return mav;
	}

}
