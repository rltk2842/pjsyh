package com.hdh.lastfinal;

import java.util.Locale;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HistoryController {
	
	@RequestMapping(value = "/HomeCom", method = RequestMethod.GET)
	public String HomeCom(Locale locale, Model model) {
	
		return "/History/HomeCom";
	}
	
	@RequestMapping(value = "/Company", method = RequestMethod.GET)
	public String Company(Locale locale, Model model) {
		
		return "/History/Company";
	}
	
	@RequestMapping(value = "/Present", method = RequestMethod.GET)
	public String Present(Locale locale, Model model) {
		
		return "/History/Present";
	}
	
	@RequestMapping(value = "/homemove", method = RequestMethod.GET)
	public String homemove(Locale locale, Model model) {
		
		return "home";
	}

}
