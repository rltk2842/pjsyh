package com.hdh.lastfinal.bean;

import org.apache.ibatis.type.Alias;

@Alias("fkarPhoto")
public class FKarPhoto {
	private String fr_oriName;
	private String fr_sysName;
	public String getFr_oriName() {
		return fr_oriName;
	}
	public void setFr_oriName(String fr_oriName) {
		this.fr_oriName = fr_oriName;
	}
	public String getFr_sysName() {
		return fr_sysName;
	}
	public void setFr_sysName(String fr_sysName) {
		this.fr_sysName = fr_sysName;
	}
	
	
}
