package com.hdh.lastfinal.bean;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

@Alias("CommuComplan")
public class CommuComplan {
	private int ccnum;
	private String ccname;
	private String cccon;
	private Timestamp ccdate;	
	private int cclook;
	private int ccgood;
	private int cccmt;
	private String mid;
	private String mname;
	private String ccid;

	
	
	public String getCcid() {
		return ccid;
	}
	public void setCcid(String ccid) {
		this.ccid = ccid;
	}
	public int getCcnum() {
		return ccnum;
	}
	public void setCcnum(int ccnum) {
		this.ccnum = ccnum;
	}
	public String getCcname() {
		return ccname;
	}
	public void setCcname(String ccname) {
		this.ccname = ccname;
	}
	public String getCccon() {
		return cccon;
	}
	public void setCccon(String cccon) {
		this.cccon = cccon;
	}
	public Timestamp getCcdate() {
		return ccdate;
	}
	public void setCcdate(Timestamp ccdate) {
		this.ccdate = ccdate;
	}
	public int getCclook() {
		return cclook;
	}
	public void setCclook(int cclook) {
		this.cclook = cclook;
	}
	public int getCcgood() {
		return ccgood;
	}
	public void setCcgood(int ccgood) {
		this.ccgood = ccgood;
	}
	public int getCccmt() {
		return cccmt;
	}
	public void setCccmt(int cccmt) {
		this.cccmt = cccmt;
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
		
	
	
	
	
}
