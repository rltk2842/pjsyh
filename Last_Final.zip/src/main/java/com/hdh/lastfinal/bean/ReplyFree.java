package com.hdh.lastfinal.bean;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonFormat;


@Alias("ReplyFree")
public class ReplyFree {
	private int rf_num;//댓글번호
	private String rf_con;//댓글내용
	private int cf_num;//글번호
	@JsonFormat(pattern = "yyyy-mm-dd hh:mm:ss")
	private Timestamp rf_date;//댓글 날짜     //Timestamp 오라클과 맞춰주기위한 형식 다른건 String도 상관없음
	private String m_id;//댓글 아이디
	
	
	public int getRf_num() {
		return rf_num;
	}
	public void setRf_num(int rf_num) {
		this.rf_num = rf_num;
	}
	public String getRf_con() {
		return rf_con;
	}
	public void setRf_con(String rf_con) {
		this.rf_con = rf_con;
	}
	public int getCf_num() {
		return cf_num;
	}
	public void setCf_num(int cf_num) {
		this.cf_num = cf_num;
	}
	public Timestamp getRf_date() {
		return rf_date;
	}
	public void setRf_date(Timestamp rf_date) {
		this.rf_date = rf_date;
	}
	public String getM_id() {
		return m_id;
	}
	public void setM_id(String m_id) {
		this.m_id = m_id;
	}
	
	
	
	
	

	
}
