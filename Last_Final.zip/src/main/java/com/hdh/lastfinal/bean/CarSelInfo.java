package com.hdh.lastfinal.bean;

import org.apache.ibatis.type.Alias;

@Alias("csinfo")
public class CarSelInfo {
	private int ktc_num;
	private String ktc_model;
	private String ktc_com;
	private String ktc_cate;
	private String ktc_year;
	private String ktc_group;
	private String ktc_gear;
	private String ktc_km;
	private String ktc_lease;
	private String ktc_month;
	private String ktc_number;
	private String ktc_price;
	private String ktc_rank;
	private String ktc_sago;
	private String ktc_size;
	private String ktc_align;
	
	public int getKtc_num() {
		return ktc_num;
	}
	public void setKtc_num(int ktc_num) {
		this.ktc_num = ktc_num;
	}
	public String getKtc_model() {
		return ktc_model;
	}
	public void setKtc_model(String ktc_model) {
		this.ktc_model = ktc_model;
	}
	public String getKtc_com() {
		return ktc_com;
	}
	public void setKtc_com(String ktc_com) {
		this.ktc_com = ktc_com;
	}
	public String getKtc_cate() {
		return ktc_cate;
	}
	public void setKtc_cate(String ktc_cate) {
		this.ktc_cate = ktc_cate;
	}
	public String getKtc_year() {
		return ktc_year;
	}
	public void setKtc_year(String ktc_year) {
		this.ktc_year = ktc_year;
	}
	public String getKtc_group() {
		return ktc_group;
	}
	public void setKtc_group(String ktc_group) {
		this.ktc_group = ktc_group;
	}
	public String getKtc_gear() {
		return ktc_gear;
	}
	public void setKtc_gear(String ktc_gear) {
		this.ktc_gear = ktc_gear;
	}
	public String getKtc_km() {
		return ktc_km;
	}
	public void setKtc_km(String ktc_km) {
		this.ktc_km = ktc_km;
	}
	public String getKtc_lease() {
		return ktc_lease;
	}
	public void setKtc_lease(String ktc_lease) {
		this.ktc_lease = ktc_lease;
	}
	public String getKtc_month() {
		return ktc_month;
	}
	public void setKtc_month(String ktc_month) {
		this.ktc_month = ktc_month;
	}
	public String getKtc_number() {
		return ktc_number;
	}
	public void setKtc_number(String ktc_number) {
		this.ktc_number = ktc_number;
	}
	public String getKtc_price() {
		return ktc_price;
	}
	public void setKtc_price(String ktc_price) {
		this.ktc_price = ktc_price;
	}
	public String getKtc_rank() {
		return ktc_rank;
	}
	public void setKtc_rank(String ktc_rank) {
		this.ktc_rank = ktc_rank;
	}
	public String getKtc_sago() {
		return ktc_sago;
	}
	public void setKtc_sago(String ktc_sago) {
		this.ktc_sago = ktc_sago;
	}
	public String getKtc_size() {
		return ktc_size;
	}
	public void setKtc_size(String ktc_size) {
		this.ktc_size = ktc_size;
	}
	public String getKtc_align() {
		return ktc_align;
	}
	public void setKtc_align(String ktc_align) {
		this.ktc_align = ktc_align;
	}
	
}
