package com.hdh.lastfinal.bean;

import org.apache.ibatis.type.Alias;

@Alias("Fdealerinfo")
public class Fdealerinfo {
	private String fd_num;
	private String fd_fc_num;
	private String fd_m_id;
	public String getFd_num() {
		return fd_num;
	}
	public void setFd_num(String fd_num) {
		this.fd_num = fd_num;
	}
	public String getFd_fc_num() {
		return fd_fc_num;
	}
	public void setFd_fc_num(String fd_fc_num) {
		this.fd_fc_num = fd_fc_num;
	}
	public String getFd_m_id() {
		return fd_m_id;
	}
	public void setFd_m_id(String fd_m_id) {
		this.fd_m_id = fd_m_id;
	}
	
	
}
