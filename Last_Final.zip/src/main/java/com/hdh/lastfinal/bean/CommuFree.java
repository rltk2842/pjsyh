package com.hdh.lastfinal.bean;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

@Alias("CommuFree")
public class CommuFree {
	private int cfnum;
	private String cfname;
	private String cfcon;
	private Timestamp cfdate;
	private int cflook;
	private int cfgood;
	private int cfcmt;
	private String mid;
	private String mname;
	private String cfid;
	
	
	public String getCfid() {
		return cfid;
	}
	public void setCfid(String cfid) {
		this.cfid = cfid;
	}
	public int getCfnum() {
		return cfnum;
	}
	public void setCfnum(int cfnum) {
		this.cfnum = cfnum;
	}
	public String getCfname() {
		return cfname;
	}
	public void setCfname(String cfname) {
		this.cfname = cfname;
	}
	public String getCfcon() {
		return cfcon;
	}
	public void setCfcon(String cfcon) {
		this.cfcon = cfcon;
	}
	public Timestamp getCfdate() {
		return cfdate;
	}
	public void setCfdate(Timestamp cfdate) {
		this.cfdate = cfdate;
	}
	public int getCflook() {
		return cflook;
	}
	public void setCflook(int cflook) {
		this.cflook = cflook;
	}
	public int getCfgood() {
		return cfgood;
	}
	public void setCfgood(int cfgood) {
		this.cfgood = cfgood;
	}
	public int getCfcmt() {
		return cfcmt;
	}
	public void setCfcmt(int cfcmt) {
		this.cfcmt = cfcmt;
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	
	
	
	
	
}
