package com.hdh.lastfinal.bean;

import org.apache.ibatis.type.Alias;

@Alias("CommuComplanFile")
public class CommuComplanFile {
	private String ccf_oriName;
	private String ccf_sysName;
	
	public String getCcf_oriName() {
		return ccf_oriName;
	}
	public void setCcf_oriName(String ccf_oriName) {
		this.ccf_oriName = ccf_oriName;
	}
	public String getCcf_sysName() {
		return ccf_sysName;
	}
	public void setCcf_sysName(String ccf_sysName) {
		this.ccf_sysName = ccf_sysName;
	}
	


	
	
	
	
}
