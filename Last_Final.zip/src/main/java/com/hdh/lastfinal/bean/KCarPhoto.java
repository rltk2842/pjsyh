package com.hdh.lastfinal.bean;

import org.apache.ibatis.type.Alias;

@Alias("kcarPhoto")
public class KCarPhoto {
	private String kr_oriName;
	private String kr_sysName;
	
	public String getKr_oriName() {
		return kr_oriName;
	}
	public void setKr_oriName(String kr_oriName) {
		this.kr_oriName = kr_oriName;
	}
	public String getKr_sysName() {
		return kr_sysName;
	}
	public void setKr_sysName(String kr_sysName) {
		this.kr_sysName = kr_sysName;
	}
	
	

}
