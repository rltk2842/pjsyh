package com.hdh.lastfinal.bean;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

@Alias("CommuNotice")
public class CommuNotice {
	private int cnnum;
	private String cnname;
	private String cncon;
	private Timestamp cndate;
	private int cnlook;
	private int cngood;
	private int cncmt;
	private String mid;
	private String mname;
	private String cnid;

	
	public String getCnid() {
		return cnid;
	}
	public void setCnid(String cnid) {
		this.cnid = cnid;
	}
	public int getCnnum() {
		return cnnum;
	}
	public void setCnnum(int cnnum) {
		this.cnnum = cnnum;
	}
	public String getCnname() {
		return cnname;
	}
	public void setCnname(String cnname) {
		this.cnname = cnname;
	}
	public String getCncon() {
		return cncon;
	}
	public void setCncon(String cncon) {
		this.cncon = cncon;
	}
	public Timestamp getCndate() {
		return cndate;
	}
	public void setCndate(Timestamp cndate) {
		this.cndate = cndate;
	}
	public int getCnlook() {
		return cnlook;
	}
	public void setCnlook(int cnlook) {
		this.cnlook = cnlook;
	}
	public int getCngood() {
		return cngood;
	}
	public void setCngood(int cngood) {
		this.cngood = cngood;
	}
	public int getCncmt() {
		return cncmt;
	}
	public void setCncmt(int cncmt) {
		this.cncmt = cncmt;
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	
	
	
	
}
