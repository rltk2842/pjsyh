package com.hdh.lastfinal.bean;

import org.apache.ibatis.type.Alias;

@Alias("CommuFreeFile")
public class CommuFreeFile {
	private String cff_oriName;
	private String cff_sysName;
	
	public String getCff_oriName() {
		return cff_oriName;
	}
	public void setCff_oriName(String cff_oriName) {
		this.cff_oriName = cff_oriName;
	}
	public String getCff_sysName() {
		return cff_sysName;
	}
	public void setCff_sysName(String cff_sysName) {
		this.cff_sysName = cff_sysName;
	}
	

	

	
	
}
