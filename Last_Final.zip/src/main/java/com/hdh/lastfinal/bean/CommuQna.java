package com.hdh.lastfinal.bean;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

@Alias("CommuQna")
public class CommuQna {
	private int cqnum;
	private String cqname;
	private String cqcon;
	private Timestamp cqdate;
	private int cqlook;
	private int cqgood;
	private int cqcmt;
	private String mid;
	private String mname;
	private String cqid;
	
	public String getCqid() {
		return cqid;
	}
	public void setCqid(String cqid) {
		this.cqid = cqid;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public int getCqnum() {
		return cqnum;
	}
	public void setCqnum(int cqnum) {
		this.cqnum = cqnum;
	}
	public String getCqname() {
		return cqname;
	}
	public void setCqname(String cqname) {
		this.cqname = cqname;
	}
	public String getCqcon() {
		return cqcon;
	}
	public void setCqcon(String cqcon) {
		this.cqcon = cqcon;
	}
	public Timestamp getCqdate() {
		return cqdate;
	}
	public void setCqdate(Timestamp cqdate) {
		this.cqdate = cqdate;
	}
	public int getCqlook() {
		return cqlook;
	}
	public void setCqlook(int cqlook) {
		this.cqlook = cqlook;
	}
	public int getCqgood() {
		return cqgood;
	}
	public void setCqgood(int cqgood) {
		this.cqgood = cqgood;
	}
	public int getCqcmt() {
		return cqcmt;
	}
	public void setCqcmt(int cqcmt) {
		this.cqcmt = cqcmt;
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	
	
	
	
	
}
