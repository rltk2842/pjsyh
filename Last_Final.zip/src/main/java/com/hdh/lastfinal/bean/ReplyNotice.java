package com.hdh.lastfinal.bean;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonFormat;


@Alias("ReplyNotice")
public class ReplyNotice {
	private int rn_num;//댓글번호
	private String rn_con;//댓글내용
	private int cn_num;//글번호
	@JsonFormat(pattern = "yyyy-mm-dd hh:mm:ss")
	private Timestamp rn_date;//댓글 날짜     //Timestamp 오라클과 맞춰주기위한 형식 다른건 String도 상관없음
	private String m_id;//댓글 아이디
	
	
	public int getRn_num() {
		return rn_num;
	}
	public void setRn_num(int rn_num) {
		this.rn_num = rn_num;
	}
	public String getRn_con() {
		return rn_con;
	}
	public void setRn_con(String rn_con) {
		this.rn_con = rn_con;
	}
	public int getCn_num() {
		return cn_num;
	}
	public void setCn_num(int cn_num) {
		this.cn_num = cn_num;
	}
	public Timestamp getRn_date() {
		return rn_date;
	}
	public void setRn_date(Timestamp rn_date) {
		this.rn_date = rn_date;
	}
	public String getM_id() {
		return m_id;
	}
	public void setM_id(String m_id) {
		this.m_id = m_id;
	}
	
	
	
	

	
}
