package com.hdh.lastfinal.bean;

import org.apache.ibatis.type.Alias;

@Alias("fcinfo")
public class FCarInfo {
	private String fcl_model;
	private String fcl_com;
	private String fcl_cate;
	private String fcl_year;
	private String fcl_group;
	
	public String getFcl_model() {
		return fcl_model;
	}
	public void setFcl_model(String fcl_model) {
		this.fcl_model = fcl_model;
	}
	public String getFcl_com() {
		return fcl_com;
	}
	public void setFcl_com(String fcl_com) {
		this.fcl_com = fcl_com;
	}
	public String getFcl_cate() {
		return fcl_cate;
	}
	public void setFcl_cate(String fcl_cate) {
		this.fcl_cate = fcl_cate;
	}
	public String getFcl_year() {
		return fcl_year;
	}
	public void setFcl_year(String fcl_year) {
		this.fcl_year = fcl_year;
	}
	public String getFcl_group() {
		return fcl_group;
	}
	public void setFcl_group(String fcl_group) {
		this.fcl_group = fcl_group;
	}
	
	
}
