package com.hdh.lastfinal.bean;

import org.apache.ibatis.type.Alias;

@Alias("fcsinfo")
public class FCarSellInfo {
	private int ftc_num;
	private String ftc_model;
	private String ftc_com;
	private String ftc_cate;
	private String ftc_year;
	private String ftc_group;
	private String ftc_gear;
	private String ftc_km;
	private String ftc_lease;
	private String ftc_month;
	private String ftc_number;
	private String ftc_price;
	private String ftc_rank;
	private String ftc_sago;
	private String ftc_size;
	private String ftc_align;
	public int getFtc_num() {
		return ftc_num;
	}
	public void setFtc_num(int ftc_num) {
		this.ftc_num = ftc_num;
	}
	public String getFtc_model() {
		return ftc_model;
	}
	public void setFtc_model(String ftc_model) {
		this.ftc_model = ftc_model;
	}
	public String getFtc_com() {
		return ftc_com;
	}
	public void setFtc_com(String ftc_com) {
		this.ftc_com = ftc_com;
	}
	public String getFtc_cate() {
		return ftc_cate;
	}
	public void setFtc_cate(String ftc_cate) {
		this.ftc_cate = ftc_cate;
	}
	public String getFtc_year() {
		return ftc_year;
	}
	public void setFtc_year(String ftc_year) {
		this.ftc_year = ftc_year;
	}
	public String getFtc_group() {
		return ftc_group;
	}
	public void setFtc_group(String ftc_group) {
		this.ftc_group = ftc_group;
	}
	public String getFtc_gear() {
		return ftc_gear;
	}
	public void setFtc_gear(String ftc_gear) {
		this.ftc_gear = ftc_gear;
	}
	public String getFtc_km() {
		return ftc_km;
	}
	public void setFtc_km(String ftc_km) {
		this.ftc_km = ftc_km;
	}
	public String getFtc_lease() {
		return ftc_lease;
	}
	public void setFtc_lease(String ftc_lease) {
		this.ftc_lease = ftc_lease;
	}
	public String getFtc_month() {
		return ftc_month;
	}
	public void setFtc_month(String ftc_month) {
		this.ftc_month = ftc_month;
	}
	public String getFtc_number() {
		return ftc_number;
	}
	public void setFtc_number(String ftc_number) {
		this.ftc_number = ftc_number;
	}
	public String getFtc_price() {
		return ftc_price;
	}
	public void setFtc_price(String ftc_price) {
		this.ftc_price = ftc_price;
	}
	public String getFtc_rank() {
		return ftc_rank;
	}
	public void setFtc_rank(String ftc_rank) {
		this.ftc_rank = ftc_rank;
	}
	public String getFtc_sago() {
		return ftc_sago;
	}
	public void setFtc_sago(String ftc_sago) {
		this.ftc_sago = ftc_sago;
	}
	public String getFtc_size() {
		return ftc_size;
	}
	public void setFtc_size(String ftc_size) {
		this.ftc_size = ftc_size;
	}
	public String getFtc_align() {
		return ftc_align;
	}
	public void setFtc_align(String ftc_align) {
		this.ftc_align = ftc_align;
	}
	
	
}
