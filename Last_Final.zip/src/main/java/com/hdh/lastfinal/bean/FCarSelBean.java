package com.hdh.lastfinal.bean;

import org.apache.ibatis.type.Alias;

@Alias("fcsel")
public class FCarSelBean {
	private String fcs_comp;
	private String fcs_name;
	private String fcs_year;
	private String fcs_align;
	public String getFcs_comp() {
		return fcs_comp;
	}
	public void setFcs_comp(String fcs_comp) {
		this.fcs_comp = fcs_comp;
	}
	public String getFcs_name() {
		return fcs_name;
	}
	public void setFcs_name(String fcs_name) {
		this.fcs_name = fcs_name;
	}
	public String getFcs_year() {
		return fcs_year;
	}
	public void setFcs_year(String fcs_year) {
		this.fcs_year = fcs_year;
	}
	public String getFcs_align() {
		return fcs_align;
	}
	public void setFcs_align(String fcs_align) {
		this.fcs_align = fcs_align;
	}
	
	
}
