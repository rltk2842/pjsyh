package com.hdh.lastfinal.bean;

import org.apache.ibatis.type.Alias;

//수입차 내차팔기 화면에서 insert를 위한 클래스
@Alias("Fsellinfo")
public class Fsellinfo {
	private String fc_price;
	private String fc_lease;
	private String fc_month;
	private String fc_km;
	private String fc_number;
	private String fc_longorbuy;
	private String fc_sago;
	private String fc_gear;
	private String fc_size;
	private String fc_rank;
	private String fc_cl_model;
	private String fc_m_id;
	private String fc_buysell;
	
	
	public String getFc_price() {
		return fc_price;
	}
	public void setFc_price(String fc_price) {
		this.fc_price = fc_price;
	}
	public String getFc_lease() {
		return fc_lease;
	}
	public void setFc_lease(String fc_lease) {
		this.fc_lease = fc_lease;
	}
	public String getFc_month() {
		return fc_month;
	}
	public void setFc_month(String fc_month) {
		this.fc_month = fc_month;
	}
	public String getFc_km() {
		return fc_km;
	}
	public void setFc_km(String fc_km) {
		this.fc_km = fc_km;
	}
	public String getFc_number() {
		return fc_number;
	}
	public void setFc_number(String fc_number) {
		this.fc_number = fc_number;
	}
	public String getFc_longorbuy() {
		return fc_longorbuy;
	}
	public void setFc_longorbuy(String fc_longorbuy) {
		this.fc_longorbuy = fc_longorbuy;
	}
	public String getFc_sago() {
		return fc_sago;
	}
	public void setFc_sago(String fc_sago) {
		this.fc_sago = fc_sago;
	}
	public String getFc_gear() {
		return fc_gear;
	}
	public void setFc_gear(String fc_gear) {
		this.fc_gear = fc_gear;
	}
	public String getFc_size() {
		return fc_size;
	}
	public void setFc_size(String fc_size) {
		this.fc_size = fc_size;
	}
	public String getFc_rank() {
		return fc_rank;
	}
	public void setFc_rank(String fc_rank) {
		this.fc_rank = fc_rank;
	}
	public String getFc_cl_model() {
		return fc_cl_model;
	}
	public void setFc_cl_model(String fc_cl_model) {
		this.fc_cl_model = fc_cl_model;
	}
	public String getFc_m_id() {
		return fc_m_id;
	}
	public void setFc_m_id(String fc_m_id) {
		this.fc_m_id = fc_m_id;
	}
	public String getFc_buysell() {
		return fc_buysell;
	}
	public void setFc_buysell(String fc_buysell) {
		this.fc_buysell = fc_buysell;
	}



}
