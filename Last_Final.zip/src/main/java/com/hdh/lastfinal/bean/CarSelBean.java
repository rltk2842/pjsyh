package com.hdh.lastfinal.bean;

import org.apache.ibatis.type.Alias;

@Alias("csel")
public class CarSelBean {
	private String cs_comp;
	private String cs_name;
	private String cs_year;
	private String cs_align;
	public String getCs_comp() {
		return cs_comp;
	}
	public void setCs_comp(String cs_comp) {
		this.cs_comp = cs_comp;
	}
	public String getCs_name() {
		return cs_name;
	}
	public void setCs_name(String cs_name) {
		this.cs_name = cs_name;
	}
	public String getCs_year() {
		return cs_year;
	}
	public void setCs_year(String cs_year) {
		this.cs_year = cs_year;
	}
	public String getCs_align() {
		return cs_align;
	}
	public void setCs_align(String cs_align) {
		this.cs_align = cs_align;
	}
	
	
}
