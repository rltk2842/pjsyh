package com.hdh.lastfinal.bean;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonFormat;


@Alias("ReplyQna")
public class ReplyQna {
	private int rq_num;//댓글번호
	private String rq_con;//댓글내용
	private int cq_num;//글번호
	@JsonFormat(pattern = "yyyy-mm-dd hh:mm:ss")
	private Timestamp rq_date;//댓글 날짜     //Timestamp 오라클과 맞춰주기위한 형식 다른건 String도 상관없음
	private String m_id;//댓글 아이디
	
	public int getRq_num() {
		return rq_num;
	}
	public void setRq_num(int rq_num) {
		this.rq_num = rq_num;
	}
	public String getRq_con() {
		return rq_con;
	}
	public void setRq_con(String rq_con) {
		this.rq_con = rq_con;
	}
	public int getCq_num() {
		return cq_num;
	}
	public void setCq_num(int cq_num) {
		this.cq_num = cq_num;
	}
	public Timestamp getRq_date() {
		return rq_date;
	}
	public void setRq_date(Timestamp rq_date) {
		this.rq_date = rq_date;
	}
	public String getM_id() {
		return m_id;
	}
	public void setM_id(String m_id) {
		this.m_id = m_id;
	}
	
	
	

	
}
