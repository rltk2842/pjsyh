package com.hdh.lastfinal.bean;

import org.apache.ibatis.type.Alias;

@Alias("CommuNoticeFile")
public class CommuNoticeFile {
	private String cnf_oriName;
	private String cnf_sysName;
	
	public String getCnf_oriName() {
		return cnf_oriName;
	}
	public void setCnf_oriName(String cnf_oriName) {
		this.cnf_oriName = cnf_oriName;
	}
	public String getCnf_sysName() {
		return cnf_sysName;
	}
	public void setCnf_sysName(String cnf_sysName) {
		this.cnf_sysName = cnf_sysName;
	}
	

	

	
	
}
