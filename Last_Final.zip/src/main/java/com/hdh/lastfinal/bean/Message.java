package com.hdh.lastfinal.bean;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

@Alias("Message")
public class Message {
	private int msg_num;
	private String msg_con;
	private Timestamp msg_date;
	private String m_idc;
	private String m_idr;
	
	public int getMsg_num() {
		return msg_num;
	}
	public void setMsg_num(int msg_num) {
		this.msg_num = msg_num;
	}
	public String getMsg_con() {
		return msg_con;
	}
	public void setMsg_con(String msg_con) {
		this.msg_con = msg_con;
	}
	public Timestamp getMsg_date() {
		return msg_date;
	}
	public void setMsg_date(Timestamp msg_date) {
		this.msg_date = msg_date;
	}
	public String getM_idc() {
		return m_idc;
	}
	public void setM_idc(String m_idc) {
		this.m_idc = m_idc;
	}
	public String getM_idr() {
		return m_idr;
	}
	public void setM_idr(String m_idr) {
		this.m_idr = m_idr;
	}
	
	

	
	
	
}
