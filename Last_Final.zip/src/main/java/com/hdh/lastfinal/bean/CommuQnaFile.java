package com.hdh.lastfinal.bean;

import org.apache.ibatis.type.Alias;

@Alias("CommuQnaFile")
public class CommuQnaFile {
	private String cqf_oriName;
	private String cqf_sysName;
	
	
	public String getCqf_oriName() {
		return cqf_oriName;
	}
	public void setCqf_oriName(String cqf_oriName) {
		this.cqf_oriName = cqf_oriName;
	}
	public String getCqf_sysName() {
		return cqf_sysName;
	}
	public void setCqf_sysName(String cqf_sysName) {
		this.cqf_sysName = cqf_sysName;
	}
	
	
	
	
	
	
	
}
