package com.hdh.lastfinal.bean;

import org.apache.ibatis.type.Alias;

@Alias("bfile")
public class Bfile {
	
	private String f_oriName;
	private String f_sysName;
	
	public String getF_oriName() {
		return f_oriName;
	}
	public void setF_oriName(String f_oriName) {
		this.f_oriName = f_oriName;
	}
	public String getF_sysName() {
		return f_sysName;
	}
	public void setF_sysName(String f_sysName) {
		this.f_sysName = f_sysName;
	}
	

}
