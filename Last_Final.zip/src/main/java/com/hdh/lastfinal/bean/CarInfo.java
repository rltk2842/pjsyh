package com.hdh.lastfinal.bean;

import org.apache.ibatis.type.Alias;


@Alias("cinfo")
public class CarInfo {
	private String cl_model;
	private String cl_com;
	private String cl_cate;
	private String cl_year;
	private String cl_group;
	
	public String getCl_model() {
		return cl_model;
	}
	public void setCl_model(String cl_model) {
		this.cl_model = cl_model;
	}
	public String getCl_com() {
		return cl_com;
	}
	public void setCl_com(String cl_com) {
		this.cl_com = cl_com;
	}
	public String getCl_cate() {
		return cl_cate;
	}
	public void setCl_cate(String cl_cate) {
		this.cl_cate = cl_cate;
	}
	public String getCl_year() {
		return cl_year;
	}
	public void setCl_year(String cl_year) {
		this.cl_year = cl_year;
	}
	public String getCl_group() {
		return cl_group;
	}
	public void setCl_group(String cl_group) {
		this.cl_group = cl_group;
	}
	
}
