package com.hdh.lastfinal.bean;

import org.apache.ibatis.type.Alias;


	@Alias("member")
	public class Member {
		private String m_id;
		private String m_pw;
		private String m_name;
		private String m_address;
		private String m_email;
		private String m_phone;
		private String m_cate;
		private String m_sex;
		public String getM_id() {
			return m_id;
		}
		public void setM_id(String m_id) {
			this.m_id = m_id;
		}
		public String getM_pw() {
			return m_pw;
		}
		public void setM_pw(String m_pw) {
			this.m_pw = m_pw;
		}
		public String getM_name() {
			return m_name;
		}
		public void setM_name(String m_name) {
			this.m_name = m_name;
		}
		public String getM_address() {
			return m_address;
		}
		public void setM_address(String m_address) {
			this.m_address = m_address;
		}
		public String getM_email() {
			return m_email;
		}
		public void setM_email(String m_email) {
			this.m_email = m_email;
		}
		public String getM_phone() {
			return m_phone;
		}
		public void setM_phone(String m_phone) {
			this.m_phone = m_phone;
		}
		public String getM_cate() {
			return m_cate;
		}
		public void setM_cate(String m_cate) {
			this.m_cate = m_cate;
		}
		public String getM_sex() {
			return m_sex;
		}
		public void setM_sex(String m_sex) {
			this.m_sex = m_sex;
		}
		
	}

