package com.hdh.lastfinal.bean;

import org.apache.ibatis.type.Alias;

//내차팔기 화면에서 insert를 위한 클래스
@Alias("sellinfo")
public class sellinfo {
	
	private String kc_price;
	private String kc_lease;
	private String kc_month;
	private String kc_km;
	private String kc_number;
	private String kc_longorbuy;
	private String kc_sago;
	private String kc_gear;
	private String kc_size;
	private String kc_rank;
	private String kc_cl_model;
	private String kc_m_id;
	public String getKc_price() {
		return kc_price;
	}
	public void setKc_price(String kc_price) {
		this.kc_price = kc_price;
	}
	public String getKc_lease() {
		return kc_lease;
	}
	public void setKc_lease(String kc_lease) {
		this.kc_lease = kc_lease;
	}
	public String getKc_month() {
		return kc_month;
	}
	public void setKc_month(String kc_month) {
		this.kc_month = kc_month;
	}
	public String getKc_km() {
		return kc_km;
	}
	public void setKc_km(String kc_km) {
		this.kc_km = kc_km;
	}
	public String getKc_number() {
		return kc_number;
	}
	public void setKc_number(String kc_number) {
		this.kc_number = kc_number;
	}
	public String getKc_longorbuy() {
		return kc_longorbuy;
	}
	public void setKc_longorbuy(String kc_longorbuy) {
		this.kc_longorbuy = kc_longorbuy;
	}
	public String getKc_sago() {
		return kc_sago;
	}
	public void setKc_sago(String kc_sago) {
		this.kc_sago = kc_sago;
	}
	public String getKc_gear() {
		return kc_gear;
	}
	public void setKc_gear(String kc_gear) {
		this.kc_gear = kc_gear;
	}
	public String getKc_size() {
		return kc_size;
	}
	public void setKc_size(String kc_size) {
		this.kc_size = kc_size;
	}
	public String getKc_rank() {
		return kc_rank;
	}
	public void setKc_rank(String kc_rank) {
		this.kc_rank = kc_rank;
	}
	public String getKc_cl_model() {
		return kc_cl_model;
	}
	public void setKc_cl_model(String kc_cl_model) {
		this.kc_cl_model = kc_cl_model;
	}
	public String getKc_m_id() {
		return kc_m_id;
	}
	public void setKc_m_id(String kc_m_id) {
		this.kc_m_id = kc_m_id;
	}
	
	
	
	
	
	
}
