package com.hdh.lastfinal.bean;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonFormat;


@Alias("ReplyComplan")
public class ReplyComplan {
	private int rc_num;//댓글번호
	private String rc_con;//댓글내용
	private int cc_num;//글번호
	@JsonFormat(pattern = "yyyy-mm-dd hh:mm:ss")
	private Timestamp rc_date;//댓글 날짜     //Timestamp 오라클과 맞춰주기위한 형식 다른건 String도 상관없음
	private String m_id;//댓글 아이디
	
	public int getRc_num() {
		return rc_num;
	}
	public void setRc_num(int rc_num) {
		this.rc_num = rc_num;
	}
	public String getRc_con() {
		return rc_con;
	}
	public void setRc_con(String rc_con) {
		this.rc_con = rc_con;
	}
	public int getCc_num() {
		return cc_num;
	}
	public void setCc_num(int cc_num) {
		this.cc_num = cc_num;
	}
	public Timestamp getRc_date() {
		return rc_date;
	}
	public void setRc_date(Timestamp rc_date) {
		this.rc_date = rc_date;
	}
	public String getM_id() {
		return m_id;
	}
	public void setM_id(String m_id) {
		this.m_id = m_id;
	}
	
	

	

	
}
