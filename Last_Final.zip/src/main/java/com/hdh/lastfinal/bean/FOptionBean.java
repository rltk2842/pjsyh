package com.hdh.lastfinal.bean;

import org.apache.ibatis.type.Alias;

@Alias("Foption")
public class FOptionBean {
	private String fc_number;
	private String fc_option;
	
	public String getFc_number() {
		return fc_number;
	}
	public void setFc_number(String fc_number) {
		this.fc_number = fc_number;
	}
	public String getFc_option() {
		return fc_option;
	}
	public void setFc_option(String fc_option) {
		this.fc_option = fc_option;
	}
	
	
}
