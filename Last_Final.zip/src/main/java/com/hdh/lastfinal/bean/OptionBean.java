package com.hdh.lastfinal.bean;

import org.apache.ibatis.type.Alias;

@Alias("option")
public class OptionBean {
	
	private String ol_number;
	private String ol_cate;
	private String ol_name;
	private String kc_number;
	private String kc_option;
	
	
	public String getOl_number() {
		return ol_number;
	}
	public void setOl_number(String ol_number) {
		this.ol_number = ol_number;
	}
	public String getOl_cate() {
		return ol_cate;
	}
	public void setOl_cate(String ol_cate) {
		this.ol_cate = ol_cate;
	}
	public String getOl_name() {
		return ol_name;
	}
	public void setOl_name(String ol_name) {
		this.ol_name = ol_name;
	}
	public String getKc_number() {
		return kc_number;
	}
	public void setKc_number(String kc_number) {
		this.kc_number = kc_number;
	}
	public String getKc_option() {
		return kc_option;
	}
	public void setKc_option(String kc_option) {
		this.kc_option = kc_option;
	}
	
	
	

}
