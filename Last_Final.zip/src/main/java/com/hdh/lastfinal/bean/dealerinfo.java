package com.hdh.lastfinal.bean;

import org.apache.ibatis.type.Alias;

@Alias("dealerinfo")
public class dealerinfo {
	private String kd_num;
	private String kd_kc_num;
	private String kd_m_id;
	public String getKd_num() {
		return kd_num;
	}
	public void setKd_num(String kd_num) {
		this.kd_num = kd_num;
	}
	public String getKd_kc_num() {
		return kd_kc_num;
	}
	public void setKd_kc_num(String kd_kc_num) {
		this.kd_kc_num = kd_kc_num;
	}
	public String getKd_m_id() {
		return kd_m_id;
	}
	public void setKd_m_id(String kd_m_id) {
		this.kd_m_id = kd_m_id;
	}

	
	



	
}
