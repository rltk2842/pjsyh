package com.hdh.lastfinal;

import java.util.List;
import java.util.Locale;

import javax.mail.Session;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.hdh.lastfinal.bean.CarInfo;
import com.hdh.lastfinal.bean.CarSelBean;
import com.hdh.lastfinal.bean.FCarInfo;
import com.hdh.lastfinal.bean.FCarSelBean;
import com.hdh.lastfinal.bean.FOptionBean;
import com.hdh.lastfinal.bean.Fdealerinfo;
import com.hdh.lastfinal.bean.Fsellinfo;
import com.hdh.lastfinal.bean.Member;
import com.hdh.lastfinal.bean.OptionBean;
import com.hdh.lastfinal.bean.dealerinfo;
import com.hdh.lastfinal.bean.sellinfo;
import com.hdh.lastfinal.service.CarManagement;


@Controller
public class BuyController {

private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	ModelAndView mav;
	
	@Autowired
	CarManagement cam;
	
	@Autowired
	HttpSession session;
	
	String a1, a2, a3;
	String f1, f2, f3;
	
	String s1;
	
	
	//국산차
	@RequestMapping(value = "/Buyhome", method = RequestMethod.GET)
	public String home() {

				
		return "MyCarBuy/Buyhome";
	}
	
	//수입차
	@RequestMapping(value = "/foregin", method = RequestMethod.GET)
	public ModelAndView home1() {

		
		mav = cam.getCarListF();			
		return mav;
	}
	


	@RequestMapping(value = "/carInfoP")
	public ModelAndView carInfo() {
		mav = cam.getCarListK();			
		return mav;
	}





	@RequestMapping(value = "/carListP")
	public @ResponseBody List<String> carList(@RequestParam("comp") String comp){
		List<String> cList = cam.getCarNameList(comp);
		
		System.out.println("1:"+comp);	
		a1 = comp;
		System.out.println("일번"+ a1);
		return cList;
	}

	@RequestMapping(value = "/carYearP")
	public @ResponseBody List<String> yearList(@RequestParam("name") String name){
		List<String> yList = cam.getCarYearList(name);
		
		System.out.println("2:"+name);
		a2 = name;
		
		return yList;
	}
	
	@RequestMapping(value = "/carYear1")
	public @ResponseBody String yearList1(@RequestParam("year") String year){
		List<String> yList = cam.getCarYearList(year);
		
		System.out.println("3:"+year);
		a3 = year;
		System.out.println(a1 + a2 + a3);
		
		return a1+a2+a3;
	
	}
	
	
	@RequestMapping(value = "/carSearchP")
	public @ResponseBody String carSearch(CarInfo ci){
		System.out.println(a1 + a2 + a3);
		
		ci.setCl_com(a1);
		ci.setCl_cate(a2);
		ci.setCl_year(a3);
		
		
		
		mav = cam.getCarModel(ci);
		
		System.out.println(ci.getCl_model());
		
		s1 = ci.getCl_model();
		
		return ci.getCl_model();
	}
	//수입차 은지누나 파트 시작

	@RequestMapping(value = "/fcarListP")
	public @ResponseBody List<String> fcarList(@RequestParam("comp") String comp){
		List<String> cList = cam.getCarNameListF(comp);
		
		System.out.println("1:"+comp);	
		f1 = comp;
		System.out.println("일번"+ f1);
		return cList;
	}

	@RequestMapping(value = "/fcarYearP")
	public @ResponseBody List<String> fyearList(@RequestParam("name") String name){
		List<String> yList = cam.getCarYearListF(name);
		
		System.out.println("2:"+name);
		f2 = name;
		System.out.println(f2);
		System.out.println("y : "+yList);
		return yList;
	}
	
	@RequestMapping(value = "/fcarYear1")
	public @ResponseBody String fyearList1(@RequestParam("year") String year){
		List<String> yList = cam.getCarYearListF(year);
		
		System.out.println("3:"+year);
		f3 = year;
		System.out.println(f1 + f2 + f3);
		
		return f1 + f2 + f3;
	
	}
	
	
	@RequestMapping(value = "/fcarSearchP")
	public @ResponseBody String carSearch(FCarInfo fci){
		System.out.println("fcarSearvchP : " + f1 + f2 + f3);
		
		fci.setFcl_com(f1);
		fci.setFcl_cate(f2);
		fci.setFcl_year(f3);
		
		
		System.out.println(fci);
		
		mav = cam.getCarModel1(fci);
		
		System.out.println(fci.getFcl_model());
		
		s1 = fci.getFcl_model();
		
		return fci.getFcl_model();
	}
	
	//수입차 은지누나 파트 끝
	
	
	
	@RequestMapping(value = "/dealer", method = RequestMethod.GET)
	public String dealer(Locale locale, Model model) {
		
		return "dealer";
	}
	
	@RequestMapping(value = "/foreign", method = RequestMethod.GET)
	public ModelAndView foreign() {
		
		mav = cam.getCarListF();			
		return mav;
	}
	@RequestMapping(value = "/korea", method = RequestMethod.GET)
	public ModelAndView korea() {
		
		mav = cam.getCarListK();			
		return mav;
	}
	//국산차 DB 저장
	 
	@RequestMapping(value = "/kCarInsert", method = RequestMethod.POST)
	public ModelAndView CarInsert(sellinfo se, OptionBean op, dealerinfo di, Member mb, 
			CarSelBean cs, CarInfo ci, MultipartHttpServletRequest multi, String s2) {
		
		
		String d_id = (String) session.getAttribute("d_id");
		String s_id = (String) session.getAttribute("id");
		
		System.out.println("모델1:" + s1);
		
		s2 = s1;

		System.out.println("딜러 id : " + d_id);
		System.out.println("판매자 id : " + s_id);
		mav = cam.kCarInsert(se, op, di, mb, cs, ci, multi, s2);
		return mav;
	}
	
	
	
	
	//수입차 DB 저장
	 
		@RequestMapping(value = "/fCarInsert", method = RequestMethod.POST,produces = "application/text; charset=utf8")
		public ModelAndView CarInsert(Fsellinfo fse, FOptionBean fop, Fdealerinfo fdi,FCarSelBean fcs, FCarInfo fci,
				String s2,MultipartHttpServletRequest multi, Member mb) {
			
			String d_id = (String) session.getAttribute("d_id");
			String s_id = (String) session.getAttribute("id");
			
			System.out.println(s_id);
			System.out.println("모델1:" + s1);
			
			s2 = s1;
			
			
			System.out.println("딜러 id : " + d_id);
			System.out.println("판매자 id : " + s_id);
			mav = cam.fCarInsert(fse, fop, fdi, fcs, fci,s2, multi, mb);
			return mav;
		}

	//라디오 버튼 딜러/셀프 선택
	@RequestMapping(value = "/koreaforeigncate", method = RequestMethod.GET)
	public ModelAndView koreaforeigncate(HttpServletRequest request) {
		
	String dealerorself = request.getParameter("dealerorself");
		System.out.println("딜러 : "+dealerorself);
		
		if(dealerorself.equals("dealer")) {
			mav = cam.getdealer();		
		
		}
		else {
			mav = cam.self();
		}
		
		return mav;
	}
	
	
	//딜러 선택 후 국산 수입으로 
	@RequestMapping(value = "/koreaforeigncate1", method = RequestMethod.GET)
	public String koreaforeigncate1(dealerinfo di, HttpServletRequest request, 
			@RequestParam("m_id")String d_id) {
		
		System.out.println("딜러 : "+ d_id);
		
		mav = cam.koreaforeigncate1(di, request,d_id);
		
		return "MyCarBuy/koreaforeigncate";
	}
	
	@RequestMapping(value = "/dealerorselfInsert", method = RequestMethod.GET)
	public String dealerorselfInsert(Locale locale, Model model) {
		
		return "dealerorselfInsert";
	}
}
