package com.hdh.lastfinal.dao;

import java.util.List;

import com.hdh.lastfinal.bean.CarInfo;
import com.hdh.lastfinal.bean.CarSelBean;
import com.hdh.lastfinal.bean.CarSelInfo;
import com.hdh.lastfinal.bean.FCarInfo;
import com.hdh.lastfinal.bean.FCarSelBean;
import com.hdh.lastfinal.bean.FCarSellInfo;
import com.hdh.lastfinal.bean.FOptionBean;
import com.hdh.lastfinal.bean.Fdealerinfo;
import com.hdh.lastfinal.bean.Fsellinfo;
import com.hdh.lastfinal.bean.Member;
import com.hdh.lastfinal.bean.OptionBean;
import com.hdh.lastfinal.bean.dealerinfo;
import com.hdh.lastfinal.bean.sellinfo;



public interface CarDao {
	
	List<String> getComp(String made);

	List<CarSelInfo> getCarList(String made);
	
	List<CarSelInfo> getCarhomeList(int num);

	List<FCarSellInfo> getCarhomeListF(int num);
	
	
	List<CarSelInfo> getKCarhomeList(int num);

	List<String> getCarNameList(String comp);

	List<String> getCarYearList(String name);

	List<CarSelInfo> getCarSelList(CarSelInfo csel);

	List<CarSelInfo> getCarReList(CarSelInfo csel);
	
	CarSelInfo getCarContent(Integer tcNum);
	
	List<OptionBean> getOptionList();

	OptionBean carOption(OptionBean ob);

	int getOptionCount();
	
	int getKCarCount();
	
	//박경민 ............
	List<CarInfo> getCompK();

	List<CarInfo> getCompF();
	
	List<Member> getdealer();

	

	boolean kcarInsert(sellinfo se);
	
	boolean opInsert(OptionBean op);

	boolean diInsert(dealerinfo di);
	
	boolean mbInsert(Member mb);
	
	boolean csInsert(CarSelBean cs);
	
	boolean fcsInsert(FCarSelBean fcs);

	String getCarYearList1(CarSelBean csel);
	
	String getCarYearList1(FCarSelBean fcsel);
	
	String getModel(CarInfo ci);
	
	String getModel1(FCarInfo fci);
	
	

	boolean fcarInsert(Fsellinfo fse);

	List<String> getCarNameListF(String comp);
	
	List<String> getCarYearListF(String name);

	boolean FdiInsert(Fdealerinfo fdi);

	boolean FopInsert(FOptionBean fop);

	List<String> getCarhome(int num);

	boolean getCarUpdate(String ktc_number);

	List<sellinfo> PurCarList(String id);


	List<sellinfo> PurManageList(String id);


	


}
