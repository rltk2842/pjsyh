package com.hdh.lastfinal.dao;

import java.util.List;
import java.util.Map;

import com.hdh.lastfinal.MessageController;
import com.hdh.lastfinal.bean.Message;





public interface IMessageDao {

	List<Message> CallMsgList(Map<String, String> jMap);

	int CallMsgCount(String id);

	List<Message> ReceiveMsgList(Map<String, String> jMap);

	int ReceiveMsgCount(String id);

	boolean MessageInsert(Message message);

	
	

	
}
