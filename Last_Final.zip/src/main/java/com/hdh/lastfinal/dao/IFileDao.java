package com.hdh.lastfinal.dao;

import java.util.List;
import java.util.Map;

import com.hdh.lastfinal.bean.Bfile;
import com.hdh.lastfinal.bean.FKarPhoto;
import com.hdh.lastfinal.bean.KCarPhoto;

public interface IFileDao {

	boolean fileInsert(Map<String, String> fMap);

	List<Bfile> PhotoSearch(String id);

	boolean KRfileInsert(Map<String, String> fMap);

	List<Bfile> MainPhotoSearch(List<String> kr_number);

	List<KCarPhoto> KcarPhoto(String kNumber);
	
	List<FKarPhoto> FcarPhoto(String fNumber);

	boolean FRfileInsert(Map<String, String> fMap);

	List<KCarPhoto> KcarPhotoMain(int num);


}
