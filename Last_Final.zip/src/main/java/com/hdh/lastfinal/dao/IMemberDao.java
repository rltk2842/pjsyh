package com.hdh.lastfinal.dao;

import java.util.List;

import com.hdh.lastfinal.bean.Member;

public interface IMemberDao {

	boolean memberInsert(Member mb);

	String getSecurityPwd(String m_ID);

	Member getMemberInfo(String id);

	Member getMyInfo(String m_ID);

	String searchId(String m_email);

	String searchPw(String m_id);

	boolean memberUpdate(Member mb);

	Member memberSelect(String id);

	String IDSelect(String email);

	boolean UpdatePW(Member mb);

	void pwSearch(String id);

	Member memberPw(String id);

	Member memberSearch();

	List<Member> getMemList(int num);

	int getMemCount();

	boolean memGeneral(Member mb);

	Member selectGeneral(String id);

	boolean memDealer(Member mb);

	Member selectDealer(String id);

	Member selectBlock(String id);

	boolean memBlock(Member mb);

	Member memCate(String id);



	
}