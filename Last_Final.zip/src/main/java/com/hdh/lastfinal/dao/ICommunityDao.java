package com.hdh.lastfinal.dao;

import java.util.List;
import java.util.Map;

import com.hdh.lastfinal.bean.CommuComplan;
import com.hdh.lastfinal.bean.CommuComplanFile;
import com.hdh.lastfinal.bean.CommuFree;
import com.hdh.lastfinal.bean.CommuFreeFile;
import com.hdh.lastfinal.bean.CommuNotice;
import com.hdh.lastfinal.bean.CommuQna;
import com.hdh.lastfinal.bean.ReplyComplan;
import com.hdh.lastfinal.bean.ReplyFree;
import com.hdh.lastfinal.bean.ReplyNotice;
import com.hdh.lastfinal.bean.ReplyQna;



public interface ICommunityDao {
//////////////////////////////////////////////////Notice 전용
	
//Notice 리스트 출력
	List<CommuNotice> getCommuNoticeList(int num);
//Notice 리스트 갯수
	int getCommuNoticeCount();
//Notice 글 입력
	boolean CommuNoticeInsert(CommuNotice commuNotice);
//Notice 글  상세
	CommuNotice getNoticeContents(Integer cnnum);
//Notice 조회수 +1
	void updateNoticelook(CommuNotice commu);
//Notice 댓글 리스트 출력
	List<ReplyNotice> getNoticeReplyList(int cnnum);
//Notice 댓글 삭제
	void replysNoticeDelete(String cnnum);
//Notice 글 삭제
	void CommuNoticeDelete(String cnnum);
//Notice 댓글 입력
	boolean replyNoticeInsert(ReplyNotice rn);
//Notice 댓글 삭제
	boolean replyNoticeDelete(ReplyNotice rn);
//Notice 댓글 수정	
	boolean replyNoticeUpdate(ReplyNotice rn);
//Notice 게시글 수정
	boolean CommuNoticeUpdate(CommuNotice commuNotice);
//Notice 게시글 검색	
	List<CommuNotice> CommuNoticeSearch(Map<String, String> map);	
	
	
//////////////////////////////////////////////////Qna 전용
	
//Qna 리스트 출력
	List<CommuQna> getCommuQnaList(int num);
//Qna 리스트 갯수
	int getCommuQnaCount();
//Qna 글 입력
	boolean CommuQnaInsert(CommuQna commuQna);
//Qna 글 상세
	CommuQna getQnaContents(Integer cqnum);
//Qna 글 조회수 1+
	void updateQnalook(CommuQna commu);
//Qna 댓글 리스트 출력
	List<ReplyQna> getQnaReplyList(int cqnum);
//Qna 댓글 완전 삭제
	boolean replysQnaDelete(String cqnum);
//Qna 글 완전 삭제
	void CommuQnaDelete(String cqnum);
//Qna 댓글 입력
	boolean replyQnaInsert(ReplyQna rq);
//Qna 댓글 삭제
	boolean replyQnaDelete(ReplyQna rq);
//Qna 댓글 수정
	boolean replyQnaUpdate(ReplyQna rq);
//Qna 글 수정
	boolean CommuQnaUpdate(CommuQna CommuQna);	
//Qna 게시글 검색	
	List<CommuQna> CommuQnaSearch(Map<String, String> map);
	
//////////////////////////////////////////////////Free 전용
	
//Free 게시글 리스트 출력
	List<CommuFree> getCommuFreeList(int num);
//Free 게시글 수
	int getCommuFreeCount();
//Free 글 입력
	boolean CommuFreeInsert(CommuFree commuFree);
//Free 파일  입력
	boolean CommuFreefileInsert(Map<String, String> fMap);
//Free 게시글 상세
	CommuFree getFreeContents(Integer cfnum);
//Free 조회수 +1
	void updateFreelook(CommuFree commu);
//Free 파일 리스트 출력
	List<CommuFreeFile> getFreeFileList(int cfnum);
//Free 댓글 리스트 출력
	List<ReplyFree> getFreeReplyList(int cf_num);
//Free 글의 댓글들 삭제
	void replysFreeDelete(String cfnum);
//Free 글의 파일 삭제
	void CommuFreeFileDelete(String cfnum);
//Free 글삭제
	void CommuFreeDelete(String cfnum);
//Free  댓글 입력
	boolean replyFreeInsert(ReplyFree rf);
//Free 댓글 삭제
	boolean replyFreeDelete(ReplyFree rf);
//Free 댓글 수정	
	boolean replyFreeUpdate(ReplyFree rf);
//Free 게시글 검색
	List<CommuFree> CommuFreeSearch(Map<String, String> map);
//Free 게시글 수정
	boolean CommuFreeUpdate(CommuFree commuFree);
//Free 게시글 파일 수정
	boolean CommuFreefileUpdate(Map<String, String> fMap);
	
//////////////////////////////////////////////////Complan 전용
	
//Complan 게시글 리스트 출력
	List<CommuComplan> getCommuComplanList(int num);
//Complan 게시글 갯수
	int getCommuComplanCount();
//Complan 글 입력
	boolean CommuComplanInsert(CommuComplan commuComplan);
//Complan 글 파일 입력
	boolean CommuComplanfileInsert(Map<String, String> fMap);
//Complan 게시글 상세
	CommuComplan getComplanContents(Integer ccnum);
//Complan 게시글 조회수 +1
	void updateComplanlook(CommuComplan commu);
//Complan 파일 리스트 출력
	List<CommuComplanFile> getComplanFileList(Integer ccnum);
//Complan 댓글 리스트 출력
	List<ReplyComplan> getComplanReplyList(Integer ccnum);
//Complan 글 댓글들 삭제
	void replysComplanDelete(String ccnum);
//Complan 글 파일 삭제
	void CommuComplanFileDelete(String ccnum);
//Complan 글 삭제
	void CommuComplanDelete(String ccnum);
//Complan 댓글 입력
	boolean replyComplanInsert(ReplyComplan rc);
//Complan 댓글 삭제
	boolean replyComplanDelete(ReplyComplan rc);
//Complan 댓글 수정	
	boolean replyComplanUpdate(ReplyComplan rc);
//Complan 게시글 검색
	List<CommuComplan> CommuComplanSearch(Map<String, String> map);
//Complan 게시글 수정	
	boolean CommuComplanUpdate(CommuComplan commuComplan);
//Complan 게시글 파일 수정	
	boolean CommuComplanfileUpdate(Map<String, String> fMap);

	
	
	

	



	
	

	



	

	

	
	
	
	

	
}
