package com.hdh.lastfinal;

import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.hdh.lastfinal.service.CommunityManagement;
import com.hdh.lastfinal.service.MessageManagement;



@Controller
public class MessageController {


	@Autowired
	private HttpSession Sesstion;
	
	@Autowired
	CommunityManagement com;

	@Autowired
	MessageManagement msm;
	
	ModelAndView mav;
	
//메시지 메인	
	@RequestMapping(value = "/MessageMain")
	public ModelAndView MessageMain() {
		mav = new ModelAndView();
	
		//Sesstion.setAttribute("pegecate", pegecate);
		int pegeNum = 1;
		//mav = cm.getCommuMainList(pegeNum);
		
		mav.setViewName("MessageMain");
		
		return mav;
	}
//보낸 메시지 확인		(사용자가 보낸 사람들)
	@RequestMapping(value = "/MessageCall")
	public ModelAndView MessageCall(int pegeNum) {
		mav = new ModelAndView();
	
		String id = (String) Sesstion.getAttribute("id");
		
		System.out.println("들어옴"+id +"와 페이지넘"+ pegeNum);
		
		

		mav = msm.CallMessageList(id, pegeNum);
		
		mav.setViewName("MessageCall");
		System.out.println("나옴");
		return mav;
	}

//받은 메시지 확인	(사용자에게 보낸 사람들)	
	@RequestMapping(value = "/MessageReceive")
	public ModelAndView MessageReceive(int pegeNum) {
		mav = new ModelAndView();
		String id = (String) Sesstion.getAttribute("id");
		System.out.println("들어옴"+id +"와 페이지넘"+ pegeNum);
	
		mav = msm.ReceiveMessageList(id, pegeNum);
		
	
		

		mav.setViewName("MessageReceive");
		
		System.out.println("나옴");
		
		return mav;
	}
//메시지 쓰기 페이지로 이동	
	@RequestMapping(value = "/MessageWrite")
	public ModelAndView MessageWrite() {
		mav = new ModelAndView();
	
		//Sesstion.setAttribute("pegecate", pegecate);
		//int pegeNum = 1;
		//mav = cm.getCommuMainList(pegeNum);
		
		mav.setViewName("MessageWrite");
		
		return mav;
	}
	
//Ajax로 처리하는 Write 메소드
		@RequestMapping(value = "/MessageWriteAjax", method = RequestMethod.POST)
		public ModelAndView MessageWriteAjax(MultipartHttpServletRequest multi) {
			mav = msm.MessageWriteAjax(multi);		
			return mav;
		}
}
