package com.hdh.lastfinal;

import java.util.Locale;
import java.util.Random;

import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.mail.Email;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;


import com.hdh.lastfinal.bean.Member;
import com.hdh.lastfinal.bean.OptionBean;
import com.hdh.lastfinal.dao.IMemberDao;
import com.hdh.lastfinal.service.CarManagement;
import com.hdh.lastfinal.service.MemberManagement;





@Controller
public class HomeController {

	@Autowired
	private JavaMailSender mailSender;


	@Autowired
	private IMemberDao mbDao;


	ModelAndView mav;

	@Autowired
	MemberManagement mbm;//Service 클래스를 찾아서 객체 생성


	@Autowired
	CarManagement cam;//Service 클래스를 찾아서 객체 생성


	@Autowired
	HttpSession session;

	int emailcount;


	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView home(Integer pageNum) {


		mav = cam.getCarhomeList(pageNum);
		return mav;
	}
	
	@RequestMapping(value = "/image", method = RequestMethod.GET)
	public String image(Locale locale, Model model) {


		return "image";
	}
	
	@RequestMapping(value = "/image2", method = RequestMethod.GET)
	public String image2(Locale locale, Model model) {


		return "image2";
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(Locale locale, Model model) {


		return "login";
	}

	//로그인
	@RequestMapping(value = "/access", method = RequestMethod.POST)
	public ModelAndView access(Member mb) {


		mav = mbm.memberAccess(mb);

		return mav;
	}

	//로그아웃 기능
	@RequestMapping(value="/logout")
	public String logout() {

		session.invalidate();

		return "home";
	}	

	//회원가입 화면
	@RequestMapping(value = "/registry", method = RequestMethod.GET)
	public String registry(Locale locale, Model model) {


		return "registry";
	}

	
	//쪽지 메인 화면
	@RequestMapping(value = "/MessageMain", method = RequestMethod.GET)
	public String MessageMain(Locale locale, Model model) {


		return "MessageMain";
	}
	//내차 팔기 화면
	@RequestMapping(value = "/Mcsel", method = RequestMethod.GET)
	public ModelAndView Mcsel(Member mb) {


		mav = mbm.McSel(mb);

		return mav;
	}

	//아이디 찾기 - 1 화면
	@RequestMapping(value = "/SearchId_one")
	public String SearchId_one(Locale locale, Model model) {


		return "ID/SearchId_one";
	}
	//아이디 찾기 - 2 
	@RequestMapping(value = "/searchId_two", method = RequestMethod.POST)
	public ModelAndView SearchId_two(Member mb) {


		mav = mbm.SearchId(mb);

		return mav;
	}
	//비밀번호 찾기 - 1
	@RequestMapping(value = "/SearchPW_one", method = RequestMethod.GET)
	public String SearchPW_one(Member mb) {

		emailcount = 0;


		return "PW/SearchPW_one";
	}

	//비밀번호 찾기 - 3 화면
	@RequestMapping(value = "/SearchPW_three", method = RequestMethod.GET)
	public String SearchPW_three(Locale locale, Model model) {


		return "PW/SearchPW_three";
	}



	//회원추가
		@RequestMapping(value = "/memberInsert", method = RequestMethod.POST)
		public ModelAndView memberInsert(Member mb, MultipartHttpServletRequest multi) {

			mav = mbm.memberInsert(mb, multi);

			return mav;
		}

	//이메일 인증번호 확인
		@RequestMapping(value = "/CheckMail", method = RequestMethod.POST)
		public ModelAndView CheckMail(Member mb,HttpServletRequest request) {

			mav = mbm.checkMail(mb, request);

			return mav;
		}

	//랜덤 함수
	public static String numberGen(int len, int dupCd ) {

		Random rand = new Random();
		String numStr = ""; //난수가 저장될 변수

		for(int i=0;i<len;i++) {

			//0~9 까지 난수 생성
			String ran = Integer.toString(rand.nextInt(10));

			if(dupCd==1) {
				//중복 허용시 numStr에 append
				numStr += ran;
			}else if(dupCd==2) {
				//중복을 허용하지 않을시 중복된 값이 있는지 검사한다
				if(!numStr.contains(ran)) {
					//중복된 값이 없으면 numStr에 append
					numStr += ran;
				}else {
					//생성된 난수가 중복되면 루틴을 다시 실행한다
					i-=1;
				}
			}
		}
		return numStr;
	}

	// mailSending 코드
	@RequestMapping(value = "/mailSending" , method = RequestMethod.POST)
	public ModelAndView mailSending(HttpServletRequest request, Member mb) {


		if(emailcount == 0) {

			mav = mbm.searchPw(mb, request);		

			if(mav.getViewName() == "PW/mailForm") {

				Random ran = new Random();

				String setfrom = "rltk2842@gmail.com";         
				String tomail  = request.getParameter("tomail");     // 받는 사람 이메일
				String title   = "인증번호";      // 제목
				String content = numberGen(5,1);     // 내용

				try {
					MimeMessage message = mailSender.createMimeMessage();
					MimeMessageHelper messageHelper 
					= new MimeMessageHelper(message, true, "UTF-8");

					messageHelper.setFrom(setfrom);  // 보내는사람 생략하거나 하면 정상작동을 안함
					messageHelper.setTo(tomail);     // 받는사람 이메일
					messageHelper.setSubject(title); // 메일제목은 생략이 가능하다
					messageHelper.setText(content);  // 메일 내용


					mailSender.send(message);
				} catch(Exception e){
					System.out.println(e);
				}

				session.setAttribute("content", content);
				session.setAttribute("m_id", mb.getM_id());
			}
			emailcount++;
		}
		else {
			mav.setViewName("PW/mailForm");
		}


		return mav;
	}

	//회사 소개
	@RequestMapping(value = "/PresentPage", method = RequestMethod.GET)
	public String HomeComPage(Locale locale, Model model) {

		return "redirect:/Present";
	}

	//가이드 화면
	@RequestMapping(value = "/GuideHomePage", method = RequestMethod.GET)
	public String GuideHomePadg(Locale locale, Model model) {

		return "redirect:/GuideHome";
	}

	//마이페이지 화면
	@RequestMapping(value = "/MyPageMove", method = RequestMethod.GET)
	public String MyPageMove(Locale locale, Model model) {


		return "redirect:/MyPage";
	}
	
	//내차팔기 화면
		@RequestMapping(value = "/BuyhomeMove", method = RequestMethod.GET)
		public String BuyHomeMove(Locale locale, Model model) {


			return "redirect:/Buyhome";
		}







	//국산차 화면
	@RequestMapping(value = "/CarListMove", method = RequestMethod.GET)
	public String CarListMove(Locale locale, Model model) {


		return "redirect:/KCarMain";
	}
	
	//수입차 화면
		@RequestMapping(value = "/SCarListMove", method = RequestMethod.GET)
		public String SCarListMove(Locale locale, Model model) {


			return "redirect:/SCarMain";
		}


	@RequestMapping(value = "/OptionList", method = RequestMethod.GET)
	public ModelAndView OptionList() {

		mav = cam.CarOptionList();			
		return mav;
	}

	@RequestMapping(value = "/addOption", method = RequestMethod.GET)
	public ModelAndView addOption(OptionBean ob, HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("ol_number",request.getParameter("ol_number"));
		mav.addObject("ol_cate",request.getParameter("ol_cate"));
		mav.addObject("ol_name",request.getParameter("ol_name"));

		System.out.println(request.getParameter("ol_number"));
		System.out.println(request.getParameter("ol_cate"));
		System.out.println(request.getParameter("ol_name"));

		mav = cam.carOption(ob, request);


		return mav;
	}






}
