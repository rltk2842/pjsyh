package com.hdh.lastfinal;

import java.io.Console;
import java.text.DateFormat;
import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.hdh.lastfinal.bean.*;
import com.hdh.lastfinal.service.CommunityManagement;




@Controller
public class Community {
	
	private static final Logger logger = LoggerFactory.getLogger(Community.class);
	ModelAndView mav;
	
	@Autowired
	CommunityManagement com;
	
	@Autowired
	private HttpSession Sesstion;
	


////////////////////////////////////////////Notice 기능
//Notice 페이지 출력!!!!!!!!!!!!!	
	@RequestMapping(value = "/CommuNotice")
	public ModelAndView CommuNotice() {
		mav = new ModelAndView();
		int pegeNum = 1;
		System.out.println("공지 사항 시작  " + pegeNum);

		mav = com.getCommuNotice(pegeNum);

		return mav;
	}
//Notice 페이지 리스트 출력!!!!!!!!!!!!!	
	@RequestMapping(value = "/CommuNoticeList")
	public ModelAndView CommuNoticeList(Integer pegeNum) {
		mav = new ModelAndView();
		System.out.println("공지 사항 시작  " + pegeNum);
			mav = com.getCommuNoticeList(pegeNum);
			return mav;
	}	
//Notice 글쓰기 페이지 이동
	@RequestMapping(value = "/CommuNoticeWrite")
	public ModelAndView CommuNoticeWrite() {
		mav = new ModelAndView();
		mav.setViewName("CommuNoticeWrite");

		return mav;
	}
//Ajax로 처리하는 Write 메소드CommuNoticeDetail
	@RequestMapping(value = "/CommuNoticeWriteAjax", method = RequestMethod.POST)
	public ModelAndView CommuNoticeWriteAjax(MultipartHttpServletRequest multi) {
		mav = com.CommuNoticeWriteAjax(multi);
		return mav;
	}
//Notice 커뮤니티 상세	
	@RequestMapping(value = "/CommuNoticeDetail", method = RequestMethod.GET)
	public ModelAndView CommuNoticeDetail(Integer cnnum) {
		mav = new ModelAndView();

		mav = com.getNoticeContents(cnnum);
		return mav;
	}
//Notice 게시글 완전 삭제 
	@RequestMapping(value = "/CommuNoticeDelete", method = RequestMethod.GET)
//Method를 생략하면 GET, POST 둘 다 처리
	public ModelAndView CommuNoticeDelete(String cnnum) {
		mav = com.CommuNoticeDelete(cnnum);
		return mav;
	}
//Notice 댓글 입력
	@RequestMapping(value = "/replyNoticeInsert", produces = "application/json; charset-UTF=8")
	public @ResponseBody Map<String, List<ReplyNotice>> replyNoticeInsert(ReplyNotice rn) {
		System.out.println("댓글 입력" + rn);
		
		Map<String, List<ReplyNotice>> rMap = com.replyNoticeInsert(rn);
		
		return rMap;
	}
//Notice 댓글 삭제
	@RequestMapping(value = "/replyNoticeDelete", produces = "application/json; charset-UTF=8")
	public @ResponseBody Map<String, List<ReplyNotice>> replyNoticeDelete(ReplyNotice rn) {
		Map<String, List<ReplyNotice>> rMap = com.replyNoticeDelete(rn);

		return rMap;
	}
//Notice 댓글 수정
	@RequestMapping(value = "/replyNoticeUpdate", produces = "application/json; charset-UTF=8")
	public @ResponseBody Map<String, List<ReplyNotice>> replyNoticeUpdate(ReplyNotice rn) {
		System.out.println("수정 들어옴" + rn);

		Map<String, List<ReplyNotice>> rMap = com.replyNoticeUpdate(rn);

		return rMap;
	}
//Notice 게시글 수정 페이지 이동  
	@RequestMapping(value = "/CommuNoticeUpdatepege")
	public ModelAndView CommuNoticeUpdatepege(Integer cnnum) {

		mav = com.getNoticeContents(cnnum);

		mav.setViewName("CommuNoticeUpdate");
		return mav;
	}	
//Notice 게시글 수정 완료 
	@RequestMapping(value = "/CommuNoticeUpdate", method = RequestMethod.POST)
	public ModelAndView CommuNoticeUpdate(MultipartHttpServletRequest multi) {
		
		mav = com.CommuNoticeUpdate(multi);
		
		return mav;
	}	
//Notice 게시글 검색
	@RequestMapping(value="/CommuNoticeSearch", produces = "application/text; charset=utf8")  
	   public  @ResponseBody String CommuNoticeSearch(@RequestBody String res) {
		
		System.out.println("컨트롤시작"+res);
		 Map<String, List<CommuNotice>> json = com.CommuNoticeSearch(res);
		 String json1 = new Gson().toJson(json);
	      
	      return json1;
	   }
 	
	/////////////////////////////////////////////////////////////Qna 기능
//Qna 페이지 출력!!!!!!
	@RequestMapping(value = "/CommuQna")
	public ModelAndView CommuQna() {
		mav = new ModelAndView();
		int pegeNum = 1;
		//Sesstion.setAttribute("pegecate", pegecate);
		mav = com.getCommuQna(pegeNum);
		
		return mav;
	}
//Qna 페이지 리스트 출력!!!!!!
	@RequestMapping(value = "/CommuQnaList")
	public ModelAndView CommuQnaList(Integer pegeNum) {
		mav = new ModelAndView();
	
		//Sesstion.setAttribute("pegecate", pegecate);
		mav = com.getCommuQnaList(pegeNum);
		
		return mav;
	}	
//Qna 글쓰기 페이지 이동
	@RequestMapping(value = "/CommuQnaWrite")
	public ModelAndView CommuQnaWrite() {
		mav = new ModelAndView();
		mav.setViewName("CommuQnaWrite");

		
		return mav;
	}
//Ajax로 처리하는 Write 메소드
	@RequestMapping(value = "/CommuQnaWriteAjax", method = RequestMethod.POST)
	public ModelAndView CommuQnaWriteAjax(MultipartHttpServletRequest multi) {
		mav = com.CommuQnaWriteAjax(multi);		
		return mav;
	}
//Qna 커뮤니티 상세	
	@RequestMapping(value = "/CommuQnaDetail", method = RequestMethod.GET)
	public ModelAndView CommuDetail(Integer cqnum) {
		mav = new ModelAndView();
		
		mav = com.getQnaContents(cqnum);
		return mav;
	}
//Qna 커뮤니티 상세 파일 다운	
	@RequestMapping(value = "/Qnadownload")
	public void Qnadownload(@RequestParam Map<String, Object> params,
			HttpServletRequest req,HttpServletResponse resp) throws Exception {
		params.put("root", req.getSession().getServletContext().getRealPath("/"));
		params.put("response", resp);
		//com.QnadownLoad(params);
				
	}
//Qna 게시글 완전 삭제 
	@RequestMapping(value = "/CommuQnaDelete", method = RequestMethod.GET)
	//Method를 생략하면 GET, POST 둘 다 처리
	public ModelAndView CommuQnaDelete(String cqnum) {
		mav = com.CommuQnaDelete(cqnum);
		return mav;
	}
//Qna 댓글 입력
	@RequestMapping(value = "/replyQnaInsert", produces = "application/json; charset-UTF=8")
	public @ResponseBody Map<String, List<ReplyQna>> replyQnaInsert(ReplyQna rq){
		Map<String, List<ReplyQna>> rMap = com.replyQnaInsert(rq);		
		
		return rMap;
	}
//Qna 댓글 삭제
	@RequestMapping(value = "/replyQnaDelete", produces = "application/json; charset-UTF=8")
	public @ResponseBody Map<String, List<ReplyQna>> replyQnaDelete(ReplyQna rq){
		Map<String, List<ReplyQna>> rMap = com.replyQnaDelete(rq);  
		
		return rMap;
	}
//Qna 게시글 수정 페이지 이동  
	@RequestMapping(value = "/CommuQnaUpdatepege")
	public ModelAndView CommuQnaUpdate(Integer cqnum) {

		mav = com.getQnaContents(cqnum);

		mav.setViewName("CommuQnaUpdate");
		return mav;
	}
//Qna 댓글 수정
	@RequestMapping(value = "/replyQnaUpdate", produces = "application/json; charset-UTF=8")
	public @ResponseBody Map<String, List<ReplyQna>> replyFreeUpdate(ReplyQna rq){
		System.out.println("수정 들어옴"+rq);
		
		Map<String, List<ReplyQna>> rMap = com.replyQnaUpdate(rq);  
		
		return rMap;
	}
//Qna 게시글 수정 완료 
	@RequestMapping(value = "/CommuQnaUpdate", method = RequestMethod.POST)
	public ModelAndView CommuQnaUpdate(MultipartHttpServletRequest multi) {
		
		mav = com.CommuQnaUpdate(multi);
		
		return mav;
	}	
//Qna 게시글 검색
	@RequestMapping(value="/CommuQnaSearch", produces = "application/text; charset=utf8")  
	   public  @ResponseBody String CommuQnaSearch(@RequestBody String res) {
		
		System.out.println("컨트롤시작"+res);
		 Map<String, List<CommuQna>> json = com.CommuQnaSearch(res);
		 String json1 = new Gson().toJson(json);
	      
	      return json1;
	   }				
	
////////////////////////////////////////////Free 기능
// Free 페이지 출력!!!!!!!!!!!!!
	@RequestMapping(value = "/CommuFree")
	public ModelAndView CommuFree() {
		mav = new ModelAndView();
		int pegeNum = 1;
		System.out.println("컨트롤 시작"+pegeNum);
		mav = com.getCommuFree(pegeNum);
		
		System.out.println("컨트롤 나옴");
				
		return mav;
	}
// Free 페이지 리스트 출력!!!!!!!!!!!!!
	@RequestMapping(value = "/CommuFreeList")
	public ModelAndView CommuFreeList(Integer pegeNum) {
		mav = new ModelAndView();
		System.out.println("컨트롤 시작"+pegeNum);
		mav = com.getCommuFreeList(pegeNum);
		
		System.out.println("컨트롤 나옴");
					
		return mav;
	}	
// Free 글쓰기 페이지 이동
	@RequestMapping(value = "/CommuFreeWrite")
	public ModelAndView CommuFreeWrite() {
		mav = new ModelAndView();
		mav.setViewName("CommuFreeWrite");
			
		return mav;
	}	
//Ajax로 처리하는 Write 메소드
	@RequestMapping(value = "/CommuFreeWriteAjax", method = RequestMethod.POST)
	public ModelAndView CommuFreeWriteAjax(MultipartHttpServletRequest multi) {
		
		
		
		mav = com.CommuFreeWriteAjax(multi);	
		
		
		return mav;
	}	
//Free 커뮤니티 상세	
	@RequestMapping(value = "/CommuFreeDetail", method = RequestMethod.GET)
	public ModelAndView CommuFreeDetail(Integer cfnum) {
		mav = new ModelAndView();
		
		mav = com.getFreeContents(cfnum);
		return mav;
	}
//Free 게시글의 파일 다운 받기
		@RequestMapping(value="/download")
		public void download(@RequestParam Map<String,Object> params,
				HttpServletRequest req,HttpServletResponse resp) throws Exception {
			//파일 경로 설정을 위한 루트 경로 구하기
			params.put("root",req.getSession().getServletContext().getRealPath("/"));
			params.put("resp",resp);
			com.downLoad(params);
		}
//Free 게시글 완전 삭제 
	@RequestMapping(value = "/CommuFreeDelete", method = RequestMethod.GET)
	//Method를 생략하면 GET, POST 둘 다 처리
	public ModelAndView CommuFreeDelete(String cfnum) {
		mav = com.CommuFreeDelete(cfnum);
		return mav;
	}
//Free 댓글 입력
	@RequestMapping(value = "/replyFreeInsert", produces = "application/json; charset-UTF=8")
	public @ResponseBody Map<String, List<ReplyFree>> replyFreeInsert(ReplyFree rf){
		Map<String, List<ReplyFree>> rMap = com.replyFreeInsert(rf);		
		
		return rMap;
	}
//Free 댓글 삭제
	@RequestMapping(value = "/replyFreeDelete", produces = "application/json; charset-UTF=8")
	public @ResponseBody Map<String, List<ReplyFree>> replyFreeDelete(ReplyFree rf){
		Map<String, List<ReplyFree>> rMap = com.replyFreeDelete(rf);  
		
		return rMap;
	}	
//Free 댓글 수정
	@RequestMapping(value = "/replyFreeUpdate", produces = "application/json; charset-UTF=8")
	public @ResponseBody Map<String, List<ReplyFree>> replyFreeUpdate(ReplyFree rf){
		System.out.println("수정 들어옴"+rf);
		
		Map<String, List<ReplyFree>> rMap = com.replyFreeUpdate(rf);  
		
		return rMap;
	}
//Free 게시글 검색
	@RequestMapping(value="/CommuFreeSearch", produces = "application/text; charset=utf8")  
	public  @ResponseBody String CommuFreeSearch(@RequestBody String res) {
		
		System.out.println("컨트롤시작"+res);
		 Map<String, List<CommuFree>> json = com.CommuFreeSearch(res);
		 String json1 = new Gson().toJson(json);
	      
	      return json1;
	   }			
//Free 게시글 수정 페이지 이동  
	@RequestMapping(value = "/CommuFreeUpdatepege")
	public ModelAndView CommuFreeUpdatepege(Integer cfnum) {
			mav = com.getFreeContents(cfnum);
			mav.setViewName("CommuFreeUpdate");
		return mav;
	}
//Free 게시글 수정 완료 
@RequestMapping(value = "/CommuFreeUpdate", method = RequestMethod.POST)
	public ModelAndView CommuFreeUpdate(MultipartHttpServletRequest multi) {
	
	mav = com.CommuFreeUpdate(multi);
	
	return mav;
}	
	
////////////////////////////////////////////Complan 기능
// Complan 메인 출력!!!!!!!!!!!!!
	@RequestMapping(value = "/CommuComplan")
	public ModelAndView CommuComplan() {
		mav = new ModelAndView();
		int pegeNum = 1;
		System.out.println("신고게시판 시작 "+pegeNum);

		mav = com.getCommuComplan(pegeNum);

		System.out.println("신고게시판 컨트롤 끝"+pegeNum);
		return mav;
	}
// Complan 페이지 리스트 출력!!!!!!!!!!!!!
	@RequestMapping(value = "/CommuComplanList")
	public ModelAndView CommuComplanList(Integer pegeNum) {
		mav = new ModelAndView();
		
		System.out.println("신고게시판 시작 "+pegeNum);

		mav = com.getCommuComplanList(pegeNum);

		System.out.println("신고게시판 컨트롤 끝"+pegeNum);
		return mav;
	}	
//Complan 글쓰기 페이지 이동
	@RequestMapping(value = "/CommuComplanWrite")
	public ModelAndView CommuComplanWrite() {
		mav = new ModelAndView();
		mav.setViewName("CommuComplanWrite");
			
		return mav;
	}	
//Ajax로 처리하는 Write 메소드CommuComplanDetail
	@RequestMapping(value = "/CommuComplanWriteAjax", method = RequestMethod.POST)
	public ModelAndView CommuComplanWriteAjax(MultipartHttpServletRequest multi) {
		
		mav = com.CommuComplanWriteAjax(multi);		
		
		return mav;
	}		
//Complan 커뮤니티 상세	
	@RequestMapping(value = "/CommuComplanDetail", method = RequestMethod.GET)
	public ModelAndView CommuComplanDetail(Integer ccnum) {

		mav = new ModelAndView();
		
		mav = com.getComplanContents(ccnum);
		return mav;
	}
//Complan 게시글 완전 삭제 
	@RequestMapping(value = "/CommuComplanDelete", method = RequestMethod.GET)
	//Method를 생략하면 GET, POST 둘 다 처리
	public ModelAndView CommuComplanDelete(String ccnum) {
		mav = com.CommuComplanDelete(ccnum);
		return mav;
	}	
//Complan 댓글 입력
	@RequestMapping(value = "/replyComplanInsert", produces = "application/json; charset-UTF=8")
	public @ResponseBody Map<String, List<ReplyComplan>> replyComplanInsert(ReplyComplan rc){
		Map<String, List<ReplyComplan>> rMap = com.replyComplanInsert(rc);		
		
		return rMap;
	}
//Complan 댓글 삭제
	@RequestMapping(value = "/replyComplanDelete", produces = "application/json; charset-UTF=8")
	public @ResponseBody Map<String, List<ReplyComplan>> replyComplanDelete(ReplyComplan rc){
		Map<String, List<ReplyComplan>> rMap = com.replyComplanDelete(rc);  
		
		return rMap;
	}
//Complan 댓글 수정
	@RequestMapping(value = "/replyComplanUpdate", produces = "application/json; charset-UTF=8")
	public @ResponseBody Map<String, List<ReplyComplan>> replyComplanUpdate(ReplyComplan rc){
		System.out.println("수정 들어옴"+rc);
		
		Map<String, List<ReplyComplan>> rMap = com.replyComplanUpdate(rc);  
		
		return rMap;
	}
//Complan 게시글 검색
	@RequestMapping(value="/CommuComplanSearch", produces = "application/text; charset=utf8")  
	   public  @ResponseBody String CommuComplanSearch(@RequestBody String res) {
		
		System.out.println("컨트롤시작"+res);
		 Map<String, List<CommuComplan>> json = com.CommuComplanSearch(res);
		 String json1 = new Gson().toJson(json);
	      
	      return json1;
	   }
//Complan 게시글 수정 페이지 이동  
	@RequestMapping(value = "/CommuComplanUpdatepege")
	public ModelAndView CommuComplanUpdatepege(Integer ccnum) {
			mav = com.getComplanContents(ccnum);
			mav.setViewName("CommuComplanUpdate");
		return mav;
	}
//Complan 게시글 수정 완료 
@RequestMapping(value = "/CommuComplanUpdate", method = RequestMethod.POST)
public ModelAndView CommuComplanUpdate(MultipartHttpServletRequest multi) {
	
	System.out.println("들어왔음");
	
	mav = com.CommuComplanUpdate(multi);
	
	return mav;
}		 		

	
	
	
	
}