package com.hdh.lastfinal.service;


import java.io.File;
import java.io.IOException;
import java.util.*;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;


import com.hdh.lastfinal.MessageController;
import com.hdh.lastfinal.bean.Message;
import com.hdh.lastfinal.dao.ICommunityDao;
import com.hdh.lastfinal.dao.IMessageDao;
import com.hdh.lastfinal.util.*;



@Service
public class MessageManagement {
   
   private ModelAndView mav;
   
   //@Autowired
   //private ICommunityDao cDao;
   
   @Autowired
   private IMessageDao msDao;
   
   @Autowired
   FileProcess fileProc;
   
   @Autowired
   HttpSession session;
   
//보낸 쪽지함 확인 
   public ModelAndView CallMessageList(String id, Integer pegenum) {
      mav = new ModelAndView();
      String view = null;
      int num = (pegenum == null) ? 1 : pegenum;
      
      System.out.println("서비스 들어옴"+num);
      
      Map<String, String> jMap = null;
      jMap = new HashMap<String, String>();
      jMap.put("id", id);   
      jMap.put("pegenum",Integer.toString(num));
      
      List<Message> msgList = null;
      msgList = msDao.CallMsgList(jMap);
      
      System.out.println("여기까지 오케이"+msgList);
      
      mav.addObject("msgList", msgList);
      view = "MessageCall";
      //페이징
      String boardName = "MessageCall";
      //전체 글수
      int maxNum = msDao.CallMsgCount(id);
      
      System.out.println("전체 글수 출력 됨"+maxNum);
      
      //페이지 당 글수
      int listCnt = 10;
      //그룹당 페이지 수
      int pageCnt = 5;
      //
      Paging paging = 
            new Paging(maxNum, num, listCnt, 
                  pageCnt, boardName);
            
      mav.addObject("paging", paging.makeHtmlpaging());   
      mav.setViewName(view);
         
      return mav;
   }
//받은 쪽지 확인
   public ModelAndView ReceiveMessageList(String id, Integer pegenum) {
      mav = new ModelAndView();
      String view = null;
      int num = (pegenum == null) ? 1 : pegenum;
      
      System.out.println("서비스 들어옴"+num);
      
      Map<String, String> jMap = null;
      jMap = new HashMap<String, String>();
      jMap.put("id", id);   
      jMap.put("pegenum",Integer.toString(num));
      
      List<Message> msgList = null;
      msgList = msDao.ReceiveMsgList(jMap);
      
      System.out.println("여기까지 오케이"+msgList);
      
      mav.addObject("msgList", msgList);
      
      view = "MessageReceive";
   
      //페이징
      String boardName = "MessageReceive";
      //전체 글수
      int maxNum = msDao.ReceiveMsgCount(id);
      
      System.out.println("전체 글수 출력 됨"+maxNum);
      
      //페이지 당 글수
      int listCnt = 10;
      //그룹당 페이지 수
      int pageCnt = 5;
      //
      Paging paging = 
            new Paging(maxNum, num, listCnt, 
                  pageCnt, boardName);
            
      mav.addObject("paging", paging.makeHtmlpaging());   
      mav.setViewName(view);
         
      return mav;
   }
   public ModelAndView MessageWriteAjax(MultipartHttpServletRequest multi) {
      mav = new ModelAndView();
      String view = null;
      String con = multi.getParameter("msg_con");
      String mid = multi.getParameter("mid");
      String idr = (String) session.getAttribute("id");

      
      Message Message = new Message();

      Message.setMsg_con(con);
      Message.setM_idc(mid);
      Message.setM_idr(idr);
      
      
      //DB에 글 내용 저장 후 게시글 번호를 얻어와서
      boolean b = msDao.MessageInsert(Message);
   
      
      view = "MessageMain";
      
      mav.setViewName(view);
      return mav;
   }
   

   


   

}