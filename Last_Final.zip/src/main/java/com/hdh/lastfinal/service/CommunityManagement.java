package com.hdh.lastfinal.service;

import java.io.File;
import java.io.IOException;
import java.util.*;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.hdh.lastfinal.bean.CommuComplan;
import com.hdh.lastfinal.bean.CommuComplanFile;
import com.hdh.lastfinal.bean.CommuFree;
import com.hdh.lastfinal.bean.CommuFreeFile;
import com.hdh.lastfinal.bean.CommuNotice;

import com.hdh.lastfinal.bean.CommuQna;

import com.hdh.lastfinal.bean.ReplyComplan;
import com.hdh.lastfinal.bean.ReplyFree;
import com.hdh.lastfinal.bean.ReplyNotice;
import com.hdh.lastfinal.bean.ReplyQna;
import com.hdh.lastfinal.dao.ICommunityDao;
import com.hdh.lastfinal.util.FileProcess;
import com.hdh.lastfinal.util.Paging;

@Service
public class CommunityManagement {

	@Autowired
	private HttpSession session;

	private ModelAndView mav;

	@Autowired
	private ICommunityDao coDao;

	@Autowired
	FileProcess fileProc;

//페이징 처리용 메소드
	private String getPaging(int num, int cate) {
		int maxNum = 0;
		String boardName = "";
		// 전체 글수
		// 게시판이 여러 종류가 있다면
		if (cate == 1) {
			maxNum = coDao.getCommuQnaCount();
			boardName = "CommuQna";
		}
		if (cate == 2) {
			maxNum = coDao.getCommuFreeCount();
			boardName = "CommuFree";
		}
		if (cate == 3) {
			maxNum = coDao.getCommuComplanCount();
			boardName = "CommuComplan";
		}
		if (cate == 4) {
			maxNum = coDao.getCommuNoticeCount();
			boardName = "CommuNotice";
		}
		// 페이지 당 글수
		int listCnt = 10;
		// 그룹당 페이지 수
		int pageCnt = 5;

		Paging paging = new Paging(maxNum, num, listCnt, pageCnt, boardName);

		return paging.makeHtmlpaging();
	}

///////////////////////////////////////Notice		
//Notice 메인 출력		
	public ModelAndView getCommuNotice(Integer pegeNum) {
		mav = new ModelAndView();
		String view = null;
		int num = (pegeNum == null) ? 1 : pegeNum;

		List<CommuNotice> cList = null;
		cList = coDao.getCommuNoticeList(num);

		mav.addObject("cList", cList);
		view = "CommuNotice";
		int cate = 4; // Notice
		mav.addObject("paging", getPaging(num, cate));
		mav.setViewName(view);

		return mav;
	}

//Notice 리스트 출력		
	public ModelAndView getCommuNoticeList(Integer pegeNum) {
		mav = new ModelAndView();
		String view = null;
		int num = (pegeNum == null) ? 1 : pegeNum;

		List<CommuNotice> cList = null;
		cList = coDao.getCommuNoticeList(num);

		mav.addObject("cList", cList);
		view = "CommuNoticeList";
		int cate = 4; // Notice
		mav.addObject("paging", getPaging(num, cate));
		mav.setViewName(view);

		return mav;
	}

//Notice 글 작성
	public ModelAndView CommuNoticeWriteAjax(MultipartHttpServletRequest multi) {
		mav = new ModelAndView();
		String view = null;

		String name = multi.getParameter("cnname");
		String con = multi.getParameter("cncon");
		String mid = (String) session.getAttribute("id");

		CommuNotice CommuNotice = new CommuNotice();
		CommuNotice.setCnname(name);
		CommuNotice.setCncon(con);
		CommuNotice.setMid(mid);

//DB에 글 내용 저장 후 게시글 번호를 얻어와서
		boolean b = coDao.CommuNoticeInsert(CommuNotice);

		view = "CommuNotice";
		mav.setViewName(view);
		return mav;
	}

//Notice 상세 보기	
	public ModelAndView getNoticeContents(Integer cnnum) {
		mav = new ModelAndView();
		String view = null;
		int bviews = 0;

		CommuNotice commu = coDao.getNoticeContents(cnnum);
		commu.setCnlook(commu.getCnlook() + 1);
		coDao.updateNoticelook(commu);
		mav.addObject("CommuNotice", commu);
		// 댓글처리
		List<ReplyNotice> RnList = coDao.getNoticeReplyList(cnnum);
		mav.addObject("RnList", RnList);

		view = "CommuNoticeDetail";

		mav.setViewName(view);

		return mav;
	}

//Notice 글 삭제
	public ModelAndView CommuNoticeDelete(String cnnum) {
		mav = new ModelAndView();
		String view = null;

		// 게시글의 댓글 삭제
		coDao.replysNoticeDelete(cnnum);

		// 게시글 삭제
		coDao.CommuNoticeDelete(cnnum);

		view = "CommuNotice";
		mav.setViewName(view);

		return mav;
	}

//Notice 댓글 입력	
	public Map<String, List<ReplyNotice>> replyNoticeInsert(ReplyNotice rn) {
		Map<String, List<ReplyNotice>> jMap = null;
		// 재광 수정 8.19
		rn.setM_id((String) session.getAttribute("id"));

		if (coDao.replyNoticeInsert(rn)) {
			List<ReplyNotice> rnList = coDao.getNoticeReplyList(rn.getCn_num());
			jMap = new HashMap<String, List<ReplyNotice>>();
			jMap.put("rnList", rnList);
		} else {
			jMap = null;
		}
		return jMap;
	}

//Notice 댓글 삭제
	public Map<String, List<ReplyNotice>> replyNoticeDelete(ReplyNotice rn) {
		Map<String, List<ReplyNotice>> jMap = null;

		if (coDao.replyNoticeDelete(rn)) {
			List<ReplyNotice> rnList = coDao.getNoticeReplyList(rn.getCn_num());
			jMap = new HashMap<String, List<ReplyNotice>>();
			jMap.put("rnList", rnList);
		} else {
			jMap = null;
		}
		return jMap;
	}

//Notice 댓글 수정
	public Map<String, List<ReplyNotice>> replyNoticeUpdate(ReplyNotice rn) {
		Map<String, List<ReplyNotice>> jMap = null;

		if (coDao.replyNoticeUpdate(rn)) {
			List<ReplyNotice> rnList = coDao.getNoticeReplyList(rn.getCn_num());
			jMap = new HashMap<String, List<ReplyNotice>>();
			jMap.put("rnList", rnList);
		} else {
			jMap = null;
		}
		return jMap;
	}

//Notice 게시글 수정	
	public ModelAndView CommuNoticeUpdate(MultipartHttpServletRequest multi) {
		mav = new ModelAndView();
		String view = null;

		String name = multi.getParameter("cnname");
		String con = multi.getParameter("cncon");
		String num = multi.getParameter("cnnum");
		String mid = (String) session.getAttribute("id");

		CommuNotice CommuNotice = new CommuNotice();
		CommuNotice.setCnname(name);
		CommuNotice.setCncon(con);
		CommuNotice.setMid(mid);
		CommuNotice.setCnnum(Integer.valueOf(num));

		boolean b = coDao.CommuNoticeUpdate(CommuNotice);

		view = "CommuNoticeUpdate";
		mav.setViewName(view);

		return mav;
	}

//Notice 게시글 검색
	public Map<String, List<CommuNotice>> CommuNoticeSearch(String res) {
		Map<String, List<CommuNotice>> jMap = null;
		Map<String, String> map = new HashMap<String, String>();

		map.put("res", "%" + res + "%");

		List<CommuNotice> cList = coDao.CommuNoticeSearch(map);

		jMap = new HashMap<String, List<CommuNotice>>();
		jMap.put("cList", cList);

		return jMap;
	}

////////////////////////////////////////      Qna
//Qna 메인 출력
	public ModelAndView getCommuQna(Integer pegenum) {
		mav = new ModelAndView();
		String view = null;
		int num = (pegenum == null) ? 1 : pegenum;

		List<CommuQna> cList = null;
		cList = coDao.getCommuQnaList(num);
		mav.addObject("cList", cList);
		view = "CommuQna";
		int cate = 1; // Qna
		mav.addObject("paging", getPaging(num, cate));
		mav.setViewName(view);

		String id = (String) session.getAttribute("id");
		System.out.println("세션 아이디 값" + id);

		return mav;
	}
//Qna 리스트 출력
	public ModelAndView getCommuQnaList(Integer pegenum) {
		mav = new ModelAndView();
		String view = null;
		int num = (pegenum == null) ? 1 : pegenum;

		List<CommuQna> cList = null;
		cList = coDao.getCommuQnaList(num);
		mav.addObject("cList", cList);
		view = "CommuQnaList";
		int cate = 1; // Qna
		mav.addObject("paging", getPaging(num, cate));
		mav.setViewName(view);

		String id = (String) session.getAttribute("id");
		System.out.println("세션 아이디 값" + id);

		return mav;
	}	

//Qna 글 작성
	public ModelAndView CommuQnaWriteAjax(MultipartHttpServletRequest multi) {
		mav = new ModelAndView();
		String view = null;
//재광 수정 8.19
		String name = multi.getParameter("cqname");
		String con = multi.getParameter("cqcon");
		String mid = (String) session.getAttribute("id");

		CommuQna CommuQna = new CommuQna();
		CommuQna.setCqname(name);
		CommuQna.setCqcon(con);
		CommuQna.setMid(mid);

		// DB에 글 내용 저장 후 게시글 번호를 얻어와서
		boolean b = coDao.CommuQnaInsert(CommuQna);

		view = "CommuQna";
		mav.setViewName(view);
		return mav;
	}

//Qna 상세 보기
	public ModelAndView getQnaContents(Integer cqnum) {
		mav = new ModelAndView();
		String view = null;
		int bviews = 0;

		CommuQna commu = coDao.getQnaContents(cqnum);
		commu.setCqlook(commu.getCqlook() + 1);
		coDao.updateQnalook(commu);
		mav.addObject("CommuQna", commu);

		// 댓글처리
		List<ReplyQna> RqList = coDao.getQnaReplyList(cqnum);
		mav.addObject("RqList", RqList);
		System.out.println("댓글처리 끝" + RqList);

		view = "CommuQnaDetail";
		mav.setViewName(view);

		return mav;
	}

//Qna 글 삭제
	public ModelAndView CommuQnaDelete(String cqnum) {
		mav = new ModelAndView();
		String view = null;

		// board.setBid(session.getAttribute("id").toString());

		System.out.println("서비스단" + cqnum);
		// 게시글의 댓글 삭제
		coDao.replysQnaDelete(cqnum);
		System.out.println("여기까진 됐음");
		// 게시글 삭제
		coDao.CommuQnaDelete(cqnum);

		view = "CommuQna";

		mav.setViewName(view);

		return mav;
	}

//Qna 댓글 입력
	public Map<String, List<ReplyQna>> replyQnaInsert(ReplyQna rq) {
		Map<String, List<ReplyQna>> jMap = null;

			
		rq.setM_id((String) session.getAttribute("id"));
		if (coDao.replyQnaInsert(rq)) {
			List<ReplyQna> rqList = coDao.getQnaReplyList(rq.getCq_num());
			jMap = new HashMap<String, List<ReplyQna>>();
			jMap.put("rqList", rqList);
		} else {
			jMap = null;
		}
		return jMap;
	}

//Qna 댓글 삭제
	public Map<String, List<ReplyQna>> replyQnaDelete(ReplyQna rq) {
		Map<String, List<ReplyQna>> jMap = null;
		// r.setR_id(session.getAttribute("id").toString());

		if (coDao.replyQnaDelete(rq)) {
			List<ReplyQna> rqList = coDao.getQnaReplyList(rq.getCq_num());
			jMap = new HashMap<String, List<ReplyQna>>();
			jMap.put("rqList", rqList);
		} else {
			jMap = null;
		}
		return jMap;
	}

//Qna 댓글 수정
	public Map<String, List<ReplyQna>> replyQnaUpdate(ReplyQna rq) {
		Map<String, List<ReplyQna>> jMap = null;

		if (coDao.replyQnaUpdate(rq)) {
			System.out.println("수정 완료");
			List<ReplyQna> rqList = coDao.getQnaReplyList(rq.getCq_num());
			jMap = new HashMap<String, List<ReplyQna>>();
			jMap.put("rqList", rqList);
		} else {
			jMap = null;
		}
		return jMap;
	}

//Qna 게시글 수정
	public ModelAndView CommuQnaUpdate(MultipartHttpServletRequest multi) {
		mav = new ModelAndView();
		String view = null;

		String name = multi.getParameter("cqname");
		String con = multi.getParameter("cqcon");
		String num = multi.getParameter("cqnum");
		String mid = (String) session.getAttribute("id");

		CommuQna CommuQna = new CommuQna();
		CommuQna.setCqname(name);
		CommuQna.setCqcon(con);
		CommuQna.setMid(mid);
		CommuQna.setCqnum(Integer.valueOf(num));

		boolean b = coDao.CommuQnaUpdate(CommuQna);

		view = "CommuQnaUpdate";
		mav.setViewName(view);

		return mav;
	}

//Qna 게시글 검색
	public Map<String, List<CommuQna>> CommuQnaSearch(String res) {
		Map<String, List<CommuQna>> jMap = null;
		Map<String, String> map = new HashMap<String, String>();

		map.put("res", "%" + res + "%");

		List<CommuQna> cList = coDao.CommuQnaSearch(map);

		jMap = new HashMap<String, List<CommuQna>>();
		jMap.put("cList", cList);

		return jMap;
	}

////////////////////////////////////////        Free
//Free  출력
	public ModelAndView getCommuFree(Integer pegenum) {
		mav = new ModelAndView();
		String view = null;
		int num = (pegenum == null) ? 1 : pegenum;
		System.out.println("출력 페이지 " + num);
		List<CommuFree> cList = null;
		cList = coDao.getCommuFreeList(num);

		System.out.println("서비스 시작 리스트" + cList);
		mav.addObject("cList", cList);
		view = "CommuFree";
		int cate = 2; // Free
		mav.addObject("paging", getPaging(num, cate));
		mav.setViewName(view);

		return mav;
	}

//Free 리스트 출력
	public ModelAndView getCommuFreeList(Integer pegenum) {
		mav = new ModelAndView();
		String view = null;
		int num = (pegenum == null) ? 1 : pegenum;
		System.out.println("출력 페이지 " + num);
		List<CommuFree> cList = null;
		cList = coDao.getCommuFreeList(num);

		System.out.println("서비스 시작 리스트" + cList);
		mav.addObject("cList", cList);
		view = "CommuFreeList";
		int cate = 2; // Free
		mav.addObject("paging", getPaging(num, cate));
		mav.setViewName(view);

		return mav;
	}

//Free 글 작성		
	public ModelAndView CommuFreeWriteAjax(MultipartHttpServletRequest multi) {
		mav = new ModelAndView();
		String view = null;
		String name = multi.getParameter("cfname");
		String con = multi.getParameter("cfcon");
		String mid = (String) session.getAttribute("id");
		// 파일 유무
		String check = multi.getParameter("fileCheck");

		CommuFree CommuFree = new CommuFree();
		CommuFree.setCfname(name);
		CommuFree.setCfcon(con);
		CommuFree.setMid(mid);

		// DB에 글 내용 저장 후 게시글 번호를 얻어와서
		boolean b = coDao.CommuFreeInsert(CommuFree);
		int cfnum = CommuFree.getCfnum();

		// 게시글 번호로 파일 저장(파일 자체 저장, 파일정보 저장)
		boolean f = false;// 파일저장 성공/실패
		// 카테고리 2번 Free
		int cate = 1;

		if (check.equals("1")) {
			f = fileProc.upFile(multi, cfnum, cate);

		}

		view = "CommuFree";
		mav.setViewName(view);
		return mav;
	}

//Free 상세 보기		
	public ModelAndView getFreeContents(Integer cfnum) {
		mav = new ModelAndView();
		String view = null;
		int bviews = 0;

		CommuFree commu = coDao.getFreeContents(cfnum);
		commu.setCflook(commu.getCflook() + 1);
		coDao.updateFreelook(commu);
		mav.addObject("CommuFree", commu);

		// 파일 처리
		List<CommuFreeFile> CffList = coDao.getFreeFileList(cfnum);
		mav.addObject("CffList", CffList);
		System.out.println("파일처리 끝" + CffList);

		// 댓글처리
		List<ReplyFree> RfList = coDao.getFreeReplyList(cfnum);
		mav.addObject("RfList", RfList);
		System.out.println("댓글처리 끝" + RfList);

		view = "CommuFreeDetail";

		mav.setViewName(view);

		return mav;
	}

//Free 글 삭제		
	public ModelAndView CommuFreeDelete(String cfnum) {
		mav = new ModelAndView();
		String view = null;

		// board.setBid(session.getAttribute("id").toString());

		// 게시글의 댓글 삭제
		coDao.replysFreeDelete(cfnum);
		// 게시글의 파일 삭제
		coDao.CommuFreeFileDelete(cfnum);
		// 게시글 삭제
		coDao.CommuFreeDelete(cfnum);

		view = "CommuFree";

		mav.setViewName(view);

		return mav;
	}

//Free 댓글 입력				
	public Map<String, List<ReplyFree>> replyFreeInsert(ReplyFree rf) {
		Map<String, List<ReplyFree>> jMap = null;

		rf.setM_id((String) session.getAttribute("id"));
		if (coDao.replyFreeInsert(rf)) {
			List<ReplyFree> rfList = coDao.getFreeReplyList(rf.getCf_num());
			jMap = new HashMap<String, List<ReplyFree>>();
			jMap.put("rfList", rfList);
		} else {
			jMap = null;
		}
		return jMap;
	}

//Free 댓글 삭제			
	public Map<String, List<ReplyFree>> replyFreeDelete(ReplyFree rf) {
		Map<String, List<ReplyFree>> jMap = null;
		// r.setR_id(session.getAttribute("id").toString());

		if (coDao.replyFreeDelete(rf)) {
			List<ReplyFree> rfList = coDao.getFreeReplyList(rf.getCf_num());
			jMap = new HashMap<String, List<ReplyFree>>();
			jMap.put("rfList", rfList);
		} else {
			jMap = null;
		}
		return jMap;
	}

//Free 댓글 수정
	public Map<String, List<ReplyFree>> replyFreeUpdate(ReplyFree rf) {
		Map<String, List<ReplyFree>> jMap = null;

		if (coDao.replyFreeUpdate(rf)) {
			System.out.println("수정 완료");
			List<ReplyFree> rfList = coDao.getFreeReplyList(rf.getCf_num());
			jMap = new HashMap<String, List<ReplyFree>>();
			jMap.put("rfList", rfList);
		} else {
			jMap = null;
		}
		return jMap;
	}

//Free 게시글 검색
	public Map<String, List<CommuFree>> CommuFreeSearch(String res) {
		Map<String, List<CommuFree>> jMap = null;
		Map<String, String> map = new HashMap<String, String>();

		map.put("res", "%" + res + "%");

		List<CommuFree> cList = coDao.CommuFreeSearch(map);

		jMap = new HashMap<String, List<CommuFree>>();
		jMap.put("cList", cList);

		return jMap;
	}

//Free 게시글 파일 다운
	public void downLoad(Map<String, Object> params) throws Exception {

		String oriFileName = (String) params.get("oriFileName");
		String sysFileName = (String) params.get("sysFileName");
		String root = "C:/Users/60/eclipse-workspace-ifn/Last_Final/src/main/webapp/";
		String path = root + "resources/file/" + sysFileName;

		HttpServletResponse resp = (HttpServletResponse) params.get("resp");

		fileProc.downFile(path, sysFileName, resp);
	}
//Free 게시글 수정		
	public ModelAndView CommuFreeUpdate(MultipartHttpServletRequest multi) {
		mav = new ModelAndView();
		String view = null;

		String name = multi.getParameter("cfname");
		String con = multi.getParameter("cfcon");
		String num = multi.getParameter("cfnum");
		String mid = (String) session.getAttribute("id");
		// 파일 유무
		String check = multi.getParameter("fileCheck");

		CommuFree CommuFree = new CommuFree();
		CommuFree.setCfname(name);
		CommuFree.setCfcon(con);
		CommuFree.setMid(mid);
		CommuFree.setCfnum(Integer.valueOf(num));

		boolean b = coDao.CommuFreeUpdate(CommuFree);
		int cfnum = CommuFree.getCfnum();

		// 게시글 번호로 파일 저장(파일 자체 저장, 파일정보 저장)
		boolean f = false;// 파일저장 성공/실패
		// 카테고리 3번 Free 수정
		int cate = 3;

		if (check.equals("1")) {
			f = fileProc.upFile(multi, cfnum, cate);

		}

		view = "CommuQnaUpdate";
		mav.setViewName(view);

		return mav;
	}

////////////////////////////////////////Complan	
//Complan 메인 출력
	public ModelAndView getCommuComplan(Integer pegenum) {
		mav = new ModelAndView();
		String view = null;
		int num = (pegenum == null) ? 1 : pegenum;
		List<CommuComplan> cList = null;
		cList = coDao.getCommuComplanList(num);

		mav.addObject("cList", cList);
		view = "CommuComplan";
		int cate = 3; // Complan
		mav.addObject("paging", getPaging(num, cate));
		mav.setViewName(view);

		return mav;
	}
//Complan 리스트 출력
	public ModelAndView getCommuComplanList(Integer pegenum) {
		mav = new ModelAndView();
		String view = null;
		int num = (pegenum == null) ? 1 : pegenum;
		List<CommuComplan> cList = null;
		cList = coDao.getCommuComplanList(num);

		mav.addObject("cList", cList);
		view = "CommuComplanList";
		int cate = 3; // Complan
		mav.addObject("paging", getPaging(num, cate));
		mav.setViewName(view);

		return mav;
	}
//Complan 글 작성
	public ModelAndView CommuComplanWriteAjax(MultipartHttpServletRequest multi) {
		mav = new ModelAndView();
		String view = null;
		String name = multi.getParameter("ccname");
		String con = multi.getParameter("cccon");
		String mid = (String) session.getAttribute("id");
		// 파일 유무
		String check = multi.getParameter("fileCheck");

		CommuComplan CommuComplan = new CommuComplan();
		CommuComplan.setCcname(name);
		CommuComplan.setCccon(con);
		CommuComplan.setMid(mid);

		// DB에 글 내용 저장 후 게시글 번호를 얻어와서
		boolean b = coDao.CommuComplanInsert(CommuComplan);
		int ccnum = CommuComplan.getCcnum();

		// 게시글 번호로 파일 저장(파일 자체 저장, 파일정보 저장)
		boolean f = false;// 파일저장 성공/실패
		// 카테고리 2번 Complan
		int cate = 2;

		if (check.equals("1")) {
			f = fileProc.upFile(multi, ccnum, cate);
			System.out.println("파일 저장끝 여긴 서비스");
		}

		view = "CommuComplan";
		mav.setViewName(view);
		return mav;
	}

//Complan 상세 보기		
	public ModelAndView getComplanContents(Integer ccnum) {

		mav = new ModelAndView();
		String view = null;
		int bviews = 0;

		CommuComplan commu = coDao.getComplanContents(ccnum);
		commu.setCclook(commu.getCclook() + 1);
		coDao.updateComplanlook(commu);
		mav.addObject("CommuComplan", commu);
		// 파일 처리
		List<CommuComplanFile> CcfList = coDao.getComplanFileList(ccnum);
		mav.addObject("CcfList", CcfList);
		System.out.println("파일처리 끝" + CcfList);
		// 댓글처리
		List<ReplyComplan> RcList = coDao.getComplanReplyList(ccnum);
		mav.addObject("RcList", RcList);
		System.out.println("댓글처리 끝" + RcList);

		view = "CommuComplanDetail";

		mav.setViewName(view);

		return mav;
	}

//Complan 글 삭제
	public ModelAndView CommuComplanDelete(String ccnum) {
		mav = new ModelAndView();
		String view = null;

		// 게시글의 댓글 삭제
		coDao.replysComplanDelete(ccnum);
		// 게시글의 파일 삭제
		coDao.CommuComplanFileDelete(ccnum);
		// 게시글 삭제
		coDao.CommuComplanDelete(ccnum);

		view = "CommuComplan";

		mav.setViewName(view);

		return mav;
	}

//Complan 댓글 입력		
	public Map<String, List<ReplyComplan>> replyComplanInsert(ReplyComplan rc) {
		Map<String, List<ReplyComplan>> jMap = null;

		rc.setM_id((String) session.getAttribute("id"));
		if (coDao.replyComplanInsert(rc)) {
			List<ReplyComplan> rcList = coDao.getComplanReplyList(rc.getCc_num());
			jMap = new HashMap<String, List<ReplyComplan>>();
			jMap.put("rcList", rcList);
		} else {
			jMap = null;
		}
		return jMap;
	}

//Complan 댓글 삭제
	public Map<String, List<ReplyComplan>> replyComplanDelete(ReplyComplan rc) {
		Map<String, List<ReplyComplan>> jMap = null;
		// r.setR_id(session.getAttribute("id").toString());

		if (coDao.replyComplanDelete(rc)) {
			List<ReplyComplan> rcList = coDao.getComplanReplyList(rc.getCc_num());
			jMap = new HashMap<String, List<ReplyComplan>>();
			jMap.put("rcList", rcList);
		} else {
			jMap = null;
		}
		return jMap;
	}

//Complan 댓글 수정
	public Map<String, List<ReplyComplan>> replyComplanUpdate(ReplyComplan rc) {
		Map<String, List<ReplyComplan>> jMap = null;

		if (coDao.replyComplanUpdate(rc)) {
			System.out.println("수정 완료");
			List<ReplyComplan> rcList = coDao.getComplanReplyList(rc.getCc_num());
			jMap = new HashMap<String, List<ReplyComplan>>();
			jMap.put("rcList", rcList);
		} else {
			jMap = null;
		}
		return jMap;
	}

//Complan 게시글 검색
	public Map<String, List<CommuComplan>> CommuComplanSearch(String res) {
		Map<String, List<CommuComplan>> jMap = null;
		Map<String, String> map = new HashMap<String, String>();

		map.put("res", "%" + res + "%");

		List<CommuComplan> cList = coDao.CommuComplanSearch(map);

		jMap = new HashMap<String, List<CommuComplan>>();
		jMap.put("cList", cList);

		return jMap;
	}

//Complan 게시글 수정		
	public ModelAndView CommuComplanUpdate(MultipartHttpServletRequest multi) {
		mav = new ModelAndView();
		String view = null;

		String name = multi.getParameter("ccname");
		String con = multi.getParameter("cccon");
		String num = multi.getParameter("ccnum");
		String mid = (String) session.getAttribute("id");
		// 파일 유무
		String check = multi.getParameter("fileCheck");

		CommuComplan CommuComplan = new CommuComplan();
		CommuComplan.setCcname(name);
		CommuComplan.setCccon(con);
		CommuComplan.setMid(mid);
		CommuComplan.setCcnum(Integer.valueOf(num));

		boolean b = coDao.CommuComplanUpdate(CommuComplan);
		int cfnum = CommuComplan.getCcnum();

		// 게시글 번호로 파일 저장(파일 자체 저장, 파일정보 저장)
		boolean f = false;// 파일저장 성공/실패
		// 카테고리 4번 Complan 수정
		int cate = 4;

		if (check.equals("1")) {
			f = fileProc.upFile(multi, cfnum, cate);

		}

		view = "CommuComplanUpdate";
		mav.setViewName(view);

		return mav;
	}

}
