package com.hdh.lastfinal.service;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.management.MBeanAttributeInfo;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.hdh.lastfinal.bean.Bfile;
import com.hdh.lastfinal.bean.Member;
import com.hdh.lastfinal.bean.sellinfo;
import com.hdh.lastfinal.dao.IFileDao;
import com.hdh.lastfinal.dao.IMemberDao;
import com.hdh.lastfinal.util.FileProcess;
import com.hdh.lastfinal.util.HPaging;
import com.hdh.lastfinal.util.Paging;





@Service
public class MemberManagement {
	private ModelAndView mav;

	@Autowired
	private IMemberDao mbDao; //servlet-context.xml의 mDao 객체와 연결

	@Autowired
	private IFileDao ifDao;
	
	@Autowired
	private HttpSession session;
	
	@Autowired
	FileProcess fileProc;

	public ModelAndView memberInsert(Member mb, MultipartHttpServletRequest multi) {
		mav = new ModelAndView();
		String view = null;

		//패스워드 암호화 처리
		BCryptPasswordEncoder pwdEncoder = new BCryptPasswordEncoder();

		mb.setM_pw(pwdEncoder.encode(mb.getM_pw()));

		//파일 유무
		String check = multi.getParameter("fileCheck");

		System.out.println(check);
		
		String mid = mb.getM_id();

		mbDao.memberInsert(mb);
		//그 게시글 번호로 파일 저장(파일 자체 저장, 파일정보 저장)
		boolean f = false;//파일 저장 성공/실패
		if(check.equals("1")) {
			f = fileProc.upMemFile(multi, mid);
			mav.addObject("check", 1);
		}
		if(f) {
			//쓰기 성공
			view = "home";
		}
		else {
			view = "registry";
		}
		mav.setViewName(view);

		return mav;
	}

	public ModelAndView memberAccess(Member mb) {

		mav = new ModelAndView();
		String view = null;

		BCryptPasswordEncoder pwdEncoder = new BCryptPasswordEncoder();

		//DB에서 암호화된 패스워드 얻어오기
		String endPwd = mbDao.getSecurityPwd(mb.getM_id());

		if(endPwd != null) {
			if(pwdEncoder.matches(mb.getM_pw(), endPwd)) {
				Member meber = mbDao.getMyInfo(mb.getM_id());
				session.setAttribute("id", mb.getM_id());
				session.setAttribute("cate", mb.getM_cate());
				session.setAttribute("name", meber.getM_name());
				session.setAttribute("cate", meber.getM_cate());
				//메인화면으로 전환
				//로그인 한 회원의 일부정보
				mb = mbDao.getMemberInfo(mb.getM_id());
				mav.addObject("mb", mb);
				view = "home";

			}
			else {
				view = "login";
				mav.addObject("check", 2);
			}
		}
		else {
			view = "login";
			mav.addObject("check", 2);
		}
		mav.setViewName(view);
		return mav;
	}

	public ModelAndView MyPageList(Member mb) {
		mav = new ModelAndView();
		String view = null;
		List<Bfile> blist = null;
		
		
		String id = (String)session.getAttribute("id");

		mb = mbDao.getMyInfo(id);
		
		blist = ifDao.PhotoSearch(id);
		
		System.out.println(blist);

		mav.addObject("mb", mb);
		mav.addObject("blist", blist);
		

		view = "MyPage/MyPage";
		mav.setViewName(view);
		
		return mav;
	}

	public ModelAndView MemUpdateList(Member mb) {
		mav = new ModelAndView();
		String view = null;
		String id = (String)session.getAttribute("id");

		mb = mbDao.getMyInfo(id);

		mav.addObject("mb", mb);

		view = "MyPage/MemUpdate";
		mav.setViewName(view);
		return mav;
	}

	public ModelAndView SearchId(Member mb) {

		mav = new ModelAndView();
		String view = null;
		String id = mbDao.searchId(mb.getM_email());
		mb.setM_id(id);
		mav.addObject("mb", mb);

		view = "ID/SearchId_two";

		mav.setViewName(view);

		return mav;
	}



	public ModelAndView memberUpdate(Member mb) {

		mav = new ModelAndView();
		String view = null;

		//세션값 불러오기 : id
		String id = (String)session.getAttribute("id");
		
		//새로운 멤버 생성
		Member m = mb;
		//DB 아이디로 검색 한 후 mb에 넣어줌: M_ID, M_PW, M_NAME, M_CATE, M_SEX 
		mb = mbDao.memberSelect(id);
		//그다음 mb에 페이지에서 입력한 값 입력해줌
		mb.setM_address(m.getM_address());
		mb.setM_email(m.getM_email());
		mb.setM_phone(m.getM_phone());

		//DB update
		if(mbDao.memberUpdate(mb))
		{
			//성공
			view = "home"; 
			mav.addObject("check", 3);
		}
		else {
			//실패
			view = "login";
		}

		mav.setViewName(view);


		return mav;
	}


	public ModelAndView searchPw(Member mb, HttpServletRequest request) {
		mav = new ModelAndView();
		String view = null;

		String id = mbDao.searchPw(mb.getM_id());



		if(id != null) {
			mb = mbDao.getMyInfo(id);

			String tomail  = request.getParameter("tomail");  

			mav.addObject("mb", mb);


			if(mb.getM_email().equals(tomail) ) {
				view = "PW/mailForm";
			}
			else {
				view = "PW/SearchPW_one";
				mav.addObject("check", 2);
			}
		}
		else {
			view = "PW/SearchPW_one";
			mav.addObject("check", 1);
		}
		mav.setViewName(view);

		return mav;
	}

	public ModelAndView checkMail(Member mb, HttpServletRequest request) {
		mav = new ModelAndView();
		String view = null;

		String content = (String)session.getAttribute("content");

		String rcontent = request.getParameter("content");


		if(content.equals(rcontent)) {

			view = "PW/SearchPW_three";
		}
		else {
			view = "PW/mailForm";
			mav.addObject("check", 1);
		}

		mav.setViewName(view);

		return mav;
	}

	public ModelAndView UpdatePW(Member mb) {

		mav = new ModelAndView();
		String view = null;

		//세션값 불러오기
		String id = (String)session.getAttribute("m_id");

		Member m = mb;

		mb = mbDao.memberPw(id);

		//패스워드 암호화 처리
		BCryptPasswordEncoder pwdEncoder = new BCryptPasswordEncoder();


		mb.setM_pw(pwdEncoder.encode(m.getM_pw()));

		//DB UPDATE
		if(mbDao.UpdatePW(mb)) {
			//성공
			view = "home"; 
			mav.addObject("a", 1);
		}
		else {
			//실패
			view = "PW/SearchPW_three";
			mav.addObject("a", 2);
		}
		mav.setViewName(view);
		return mav;

	}

	//멤버 가져오기
	public ModelAndView memberSearch(Integer pageNum) {
		String view = null;
		List<Member> mList = null;
		//pageNum이 널이면(로그인 한 후) 첫페이지를 보이도록.
		int num = (pageNum == null) ? 1 : pageNum;

		System.out.println("페이지 번호 1 : " +num);
		
		mList = mbDao.getMemList(num);

		System.out.println();

		mav.addObject("mList", mList);
		mav.addObject("hpaging", getPaging(num));
		view = "MyPage/MemBlock";
		mav.setViewName(view);

		return mav;
	}
	private Object getPaging(int num) {
		//전체 글수
		int maxNum = mbDao.getMemCount();
		//페이지 당 글수
		int listCnt = 10;
		//그룹당 페이지 수
		int pageCnt = 2;
		//게시판이 여러 종류가 있다면 
		String boardName = "MemBlock";
		HPaging paging = 
				new HPaging(maxNum, num, listCnt, 
						pageCnt, boardName);

		return paging.makeHtmlpaging();
	}

	public ModelAndView memGeneral(HttpServletRequest request,Member mb) {

		mav = new ModelAndView();
		String view = null;
		String id = request.getParameter("m_id");

		Member mm = mb;
		
		mb = mbDao.selectGeneral(id);
		
		mb.setM_cate("일반");
				
		System.out.println("카테고리 : "+ mb.getM_cate());
		
		//DB update
		if(mbDao.memGeneral(mb))
		{
			System.out.println("성공");
			//성공
			mav.addObject("good", 1);
			view = "home"; 

		}
		else {
			//실패
			System.out.println("실패");

			view = "MyPage/MemBlock";
		}

		mav.setViewName(view);

		return mav;
	}

	public ModelAndView memDealer(HttpServletRequest request,Member mb) {
		mav = new ModelAndView();
		String view = null;
		String id = request.getParameter("m_id");

		Member mm = mb;
		
		mb = mbDao.selectDealer(id);
		
		mb.setM_cate("딜러");
				
		System.out.println("카테고리 : "+ mb.getM_cate());
		
		//DB update
		if(mbDao.memGeneral(mb))
		{
			System.out.println("성공");
			//성공
			mav.addObject("good", 1);
			view = "home"; 

		}
		else {
			//실패
			System.out.println("실패");

			view = "MyPage/MemBlock";
		}

		mav.setViewName(view);

		return mav;
	}

	public ModelAndView memBlock(HttpServletRequest request, Member mb) {
		mav = new ModelAndView();
		String view = null;
		String id = request.getParameter("m_id");

		Member mm = mb;

		mb = mbDao.selectBlock(id);

		mb.setM_cate("블락회원");

		System.out.println("카테고리 : "+ mb.getM_cate());

		//DB update
		if(mbDao.memBlock(mb))
		{
			System.out.println("성공");
			//성공
			mav.addObject("good", 1);
			view = "home"; 

		}
		else {
			//실패
			System.out.println("실패");

			view = "MyPage/MemBlock";
		}

		mav.setViewName(view);

		return mav;
	}

	public ModelAndView McSel(Member mb) {

		mav = new ModelAndView();
		String view = null;

		String id = (String)session.getAttribute("id");
		mb = mbDao.memCate(id);

		if(mb.getM_cate().equals("블락회원")) {

			view = "home";
			mav.addObject("check", 4);
			
		}
		else {
			view = "Mcsel";
		}

		mav.setViewName(view);
		return mav;
	}

	

	







}
