package com.hdh.lastfinal.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.hdh.lastfinal.bean.Bfile;
import com.hdh.lastfinal.bean.CarInfo;
import com.hdh.lastfinal.bean.CarSelBean;
import com.hdh.lastfinal.bean.CarSelInfo;
import com.hdh.lastfinal.bean.FCarInfo;
import com.hdh.lastfinal.bean.FCarSelBean;
import com.hdh.lastfinal.bean.FCarSellInfo;
import com.hdh.lastfinal.bean.FKarPhoto;
import com.hdh.lastfinal.bean.FOptionBean;
import com.hdh.lastfinal.bean.Fdealerinfo;
import com.hdh.lastfinal.bean.Fsellinfo;
import com.hdh.lastfinal.bean.KCarPhoto;
import com.hdh.lastfinal.bean.Member;
import com.hdh.lastfinal.bean.OptionBean;
import com.hdh.lastfinal.bean.dealerinfo;
import com.hdh.lastfinal.bean.sellinfo;
import com.hdh.lastfinal.dao.CarDao;
import com.hdh.lastfinal.dao.IFileDao;
import com.hdh.lastfinal.util.FileProcess;
import com.hdh.lastfinal.util.HPaging;
import com.hdh.lastfinal.util.Paging;

import javafx.scene.control.Alert;



@Service
public class CarManagement {
	private ModelAndView mav;

	@Autowired
	CarDao caDao;
	@Autowired
	FileProcess fileProc;
	@Autowired
	IFileDao ifDao;
	@Autowired
	HttpSession session;


	public ModelAndView getCarListK(String made) {
		mav = new ModelAndView();
		List<CarSelInfo> cList = null;
		List<String> compList = null;

		compList = caDao.getComp(made);
		cList = caDao.getCarList(made);

		mav.addObject("cList", cList);
		mav.addObject("compList", compList);
		mav.setViewName("CarList/KCarMain");

		return mav;
	}

	public List<String> getCarNameListF(String comp) {
		List<String> cNameList = caDao.getCarNameListF(comp);

		System.out.println("차종" + cNameList);

		return cNameList;
	}




	public ModelAndView getCarListS(String made) {
		mav = new ModelAndView();
		List<CarSelInfo> cList = null;
		List<String> compList = null;

		compList = caDao.getComp(made);
		cList = caDao.getCarList(made);

		mav.addObject("cList", cList);
		mav.addObject("compList", compList);
		mav.setViewName("CarList/SCarMain");

		return mav;
	}


	public ModelAndView getCarModel(CarInfo ci) {

		mav = new ModelAndView();
		String view = null;
		String mv = caDao.getModel(ci);

		ci.setCl_model(mv);

		return mav;
	}

	public ModelAndView getCarhomeList(Integer pageNum) {
		mav = new ModelAndView();

		List<CarSelInfo> cList = null;
		List<FCarSellInfo> cLists = null;
		List<KCarPhoto> klist = null;
		List<FKarPhoto> flist = null;
				
		int maxNum = caDao.getOptionCount()/6;

		int num = (pageNum == null) ? maxNum : pageNum;
		
		System.out.println("번호:"+num);

		cList = caDao.getCarhomeList(num);

		cLists = caDao.getCarhomeListF(num);
		System.out.println("크기 : "+cList.size());
		//국산차 차량번호 가져오기
		
		//String KNumber = cList.get(i).getKtc_number().toString();

		
		
		klist = ifDao.KcarPhotoMain(num);
		
		//수입차 차량번호 가져오기
	//	String FNumber = cLists.get(0).getFtc_number().toString();
	//	System.out.println("수입자동차 넘버~ : " + FNumber);
		
		
		
//		flist = ifDao.FcarPhoto(FNumber);
		
		System.out.println("klist : "+klist);
		
		mav.addObject("cLists", cLists);
		mav.addObject("cList", cList);
		mav.addObject("klist", klist);
		mav.addObject("flist", flist);
		mav.addObject("paging", getPaging(num));
		mav.setViewName("home");

		return mav;
	}

	public ModelAndView getCarKoreaList(Integer pageNum) {
		mav = new ModelAndView();
		List<CarSelInfo> cList = null;
		List<String> compList = null;
		String made = "국산";


		int num = (pageNum == null) ? 1 : pageNum;
		System.out.println("num1 : " + num);


		cList = caDao.getKCarhomeList(num);
		compList = caDao.getComp(made);

		System.out.println(compList);

		mav.addObject("compList", compList);

		mav.addObject("cList", cList);
		mav.addObject("hpaging", getKPaging(num));
		mav.setViewName("CarList/KCarMain");

		return mav;
	}

	private String getKPaging(int num) {
		int maxNum = 0;
		String boardName = "";


		//전체 글수
		maxNum = caDao.getKCarCount();
		//페이지 당 글수
		int listCnt = 6;
		//그룹당 페이지 수
		int pageCnt = 2;
		//게시판이 여러 종류가 있다면 
		boardName = "KCarMain";
		HPaging paging = 
				new HPaging(maxNum, num, listCnt, 
						pageCnt, boardName);

		return paging.makeHtmlpaging();
	}


	public ModelAndView getCarhomeListS(Integer pageNum) {
		mav = new ModelAndView();


		int num = (pageNum == null) ? 1 : pageNum;

		mav.addObject("paging", getPaging(num));
		mav.setViewName("home");

		return mav;
	}

	private String getPaging(int num) {
		System.out.println("번호" + num);
		//전체 글수
		int maxNum = caDao.getOptionCount();
		//페이지 당 글수
		int listCnt = 3;
		//그룹당 페이지 수
		int pageCnt = 2;
		//게시판이 여러 종류가 있다면 
		String boardName = "home";
		Paging paging = 
				new Paging(maxNum, num, listCnt, 
						pageCnt, boardName);

		return paging.makeHtmlpaging();
	}




	public List<String> getCarNameList(String comp) {
		List<String> cNameList = caDao.getCarNameList(comp);

		return cNameList;
	}

	public List<String> getCarYearList(String name) {
		List<String> cYearList = caDao.getCarYearList(name);
		return cYearList;
	}

	public List<CarSelInfo> getCarSelList(CarSelInfo csel, String made) {
		List<CarSelInfo> sList = null;
		csel.setKtc_group(made);

		sList = caDao.getCarSelList(csel);

		return sList;
	}

	public List<CarSelInfo> getCarReList(CarSelInfo csel, String made) {
		List<CarSelInfo> sList = null;
		csel.setKtc_group(made);

		sList = caDao.getCarReList(csel);

		return sList;
	}

	public ModelAndView getCarContent(Integer ktcNum) {
		mav = new ModelAndView();
		CarSelInfo csInfo = caDao.getCarContent(ktcNum);
		mav.addObject("csInfo", csInfo);
		mav.setViewName("CarList/CarList");

		return mav;
	}


	public ModelAndView getCarUpdate(String ktc_number) {
		mav = new ModelAndView();

		System.out.println("ㅇㅋ"+ktc_number);

		if(caDao.getCarUpdate(ktc_number)) {
			mav.setViewName("CarList/KCarMain");
		}
		else {
			System.out.println("미안");
		}


		return mav;
	}

	public ModelAndView CarOptionAdd(HttpServletRequest request) {
		mav = new ModelAndView();
		String view = null;

		view = "addOption";


		mav.setViewName(view);

		return mav;
	}

	public ModelAndView CarOptionList() {
		mav = new ModelAndView();
		String view = null;

		List<OptionBean> oList = null;

		oList = caDao.getOptionList();		

		mav.addObject("oList", oList);
		view = "MyPage/OptionList";
		mav.setViewName(view);


		return mav;
	}



	public ModelAndView carOption(OptionBean ob, HttpServletRequest request) {
		mav = new ModelAndView();
		String view = null;

		mav.addObject("ol_number",request.getParameter("ol_number"));
		mav.addObject("ol_cate",request.getParameter("ol_cate"));
		mav.addObject("ol_name",request.getParameter("ol_name"));

		System.out.println("1 : " +request.getParameter("ol_number"));
		System.out.println("1 : " +request.getParameter("ol_cate"));
		System.out.println("1 : " +request.getParameter("ol_name"));

		ob = caDao.carOption(ob);
		mav.addObject("ob",ob);

		view = "OptionList";

		mav.setViewName(view);

		return mav;
	}

	public ModelAndView getCarListK() {
		mav = new ModelAndView();
		List<CarInfo> cList = null;
		String view = null;
		cList = caDao.getCompK();
		String id = (String)session.getAttribute("id");

		mav.addObject("cList", cList);
		mav.addObject("id", id);

		view= "MyCarBuy/korea";

		mav.setViewName(view);

		return mav;
	}

	public ModelAndView getCarListF() {
		mav = new ModelAndView();
		List<CarInfo> cList = null;

		cList = caDao.getCompF();

		mav.addObject("cList", cList);
		mav.setViewName("MyCarBuy/foreign");

		return mav;
	}




	public List<String> getCarYearList1(String year) {
		List<String> cYearList = caDao.getCarYearList(year);
		return cYearList;
	}

	public List<CarSelBean> getCarSelList(CarSelBean csel) {
		// TODO Auto-generated method stub
		return null;
	}



	public ModelAndView getdealer() {
		mav = new ModelAndView();
		List<Member> mList = null;


		mList = caDao.getdealer();
		mav.addObject("mList", mList);
		mav.setViewName("MyCarBuy/dealer");
		return mav;
	}

	///////////////////////////////////////

	///////////////////////////////////////

	public ModelAndView self() {
		mav = new ModelAndView();
		String view = null;

		session.removeAttribute("d_id");
		view = "MyCarBuy/koreaforeigncate";
		mav.setViewName(view);
		return mav;
	}

	public ModelAndView koreaforeigncate1(dealerinfo di, HttpServletRequest request, @RequestParam("m_id")String d_id) {
		mav = new ModelAndView();
		String view = null;

		//딜러선택시 딜러 이름을 세션값으로 저장
		session.setAttribute("d_id", d_id);
		String id = (String)session.getAttribute("id");
		mav.addObject("id", id);
		view = "MyCarBuy/koreaforeigncate";

		mav.setViewName(view);
		return mav;
	}

	public List<String> getCarYearListF(String name) {
		List<String> cYearList = caDao.getCarYearListF(name);

		System.out.println(cYearList);
		return cYearList;
	}

	public ModelAndView getCarModel1(FCarInfo fci) {

		mav = new ModelAndView();
		String view = null;
		String mv = caDao.getModel1(fci);



		fci.setFcl_model(mv);


		return mav;
	}

	public ModelAndView kCarInsert(sellinfo se, OptionBean op, dealerinfo di, Member mb, CarSelBean cs, CarInfo ci,
			MultipartHttpServletRequest multi, String s2) {
		mav = new ModelAndView();
		String view = null;
		//파일 유무
		String check = multi.getParameter("fileCheck");

		String d_id = (String) session.getAttribute("d_id");

		String mid = mb.getM_id();


		System.out.println("딜러"+ d_id);

		String id = (String)session.getAttribute("id");

		//DB insert
		se.setKc_m_id(id);

		se.setKc_cl_model(s2);

		System.out.println("모델:" +se.getKc_cl_model());

		if(caDao.kcarInsert(se)) {
			//성공
			if(caDao.opInsert(op)){

				di.setKd_m_id(d_id);
				System.out.println("1"+di.getKd_m_id());
				di.setKd_kc_num(se.getKc_number());

				System.out.println("2"+di.getKd_m_id());
				System.out.println("3"+di.getKd_kc_num());
				System.out.println(check);


				String number = se.getKc_number();

				//그 게시글 번호로 파일 저장(파일 자체 저장, 파일정보 저장)
				boolean f = false;//파일 저장 성공/실패
				if(check.equals("1")) {
					f = fileProc.upCarFile(multi, number);
					mav.addObject("check", 1);
				}

				if(d_id != null) {
					if(caDao.diInsert(di)) {
						System.out.println(di);
						view = "home"; 	  	
					}
				}
				else {
					view = "home";
				}

			}
		}
		else {
			//실패

			view = "MyCarBuy/korea";
		}
		mav.setViewName(view);
		return mav;

	}

	public ModelAndView fCarInsert(Fsellinfo fse, FOptionBean fop, Fdealerinfo fdi,FCarSelBean fcs, FCarInfo fci,
			String s2, MultipartHttpServletRequest multi, Member mb) {

		mav = new ModelAndView();
	      String view = null;
	      //파일 유무
	      String check = multi.getParameter("fileCheck");

	      String d_id = (String) session.getAttribute("d_id");
	      
	      String mid = mb.getM_id();
	      
	      System.out.println("확인차"+ mid);

	      System.out.println("딜러"+ d_id);

	      String id = (String)session.getAttribute("id");

	      System.out.println("딜러"+ id);

	      //DB insert
	      fse.setFc_m_id(id);

	      fse.setFc_cl_model(s2);

	      System.out.println("모델:" +fse.getFc_cl_model());

	      if(caDao.fcarInsert(fse)) {
	         //성공
	         if(caDao.FopInsert(fop)){

	            fdi.setFd_m_id(d_id);
	            System.out.println("1"+fdi.getFd_m_id());
	            fdi.setFd_fc_num(fse.getFc_number());

	            System.out.println("2"+fdi.getFd_m_id());
	            System.out.println("3"+fdi.getFd_fc_num());
	            System.out.println(check);
	            
	            String number = fse.getFc_number();
	             //그 게시글 번호로 파일 저장(파일 자체 저장, 파일정보 저장)
	               boolean f = false;//파일 저장 성공/실패
	               if(check.equals("1")) {
	                  f = fileProc.upFCarFile(multi, number);
	                  mav.addObject("check", 1);
	               }

	            if(d_id != null) {
	               if(caDao.FdiInsert(fdi)) {
	                  System.out.println(fdi);
	                  view = "home";         
	               }

	            }
	            else {
	               view = "home";
	            }
	         }
	      }
	      else {
	         //실패

	         view = "MyCarBuy/foreign";
	      }
	      mav.setViewName(view);
	      return mav;
	}


	public ModelAndView PurCarList(sellinfo se) {
		mav = new ModelAndView();
		String view = null;
		List<sellinfo> slist = null;
		
		String id = (String)session.getAttribute("id");

		System.out.println(id);

		if(id != null) {

		slist = caDao.PurCarList(id);
		}
		
		view = "MyPage/PurCar";
		
		System.out.println(view);

		mav.addObject("slist",slist);
		mav.setViewName(view);

		return mav;
	}

	public ModelAndView PurManage(sellinfo se) {
		mav = new ModelAndView();
		String view = null;
		List<sellinfo> slistp = null;
		
		String id = (String)session.getAttribute("id");

		System.out.println(id);

		if(id != null) {

		slistp = caDao.PurManageList(id);
		}
		
		view = "MyPage/PurManage";
		
		System.out.println(view);

		mav.addObject("slistp",slistp);
		mav.setViewName(view);

		return mav;
	}


}
