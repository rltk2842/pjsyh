package com.hdh.lastfinal.util;

import java.io.*;
import java.net.URLEncoder;
import java.util.*;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.hdh.lastfinal.dao.ICommunityDao;
import com.hdh.lastfinal.dao.IFileDao;

@Component
public class FileProcess {
	
	@Autowired
	private IFileDao ifDao;//파일 정보 저장을 위해 사용

	@Autowired
	private ICommunityDao cDao;// 파일 정보 저장을 위해 사용

	public void downFile(String path, String oriFileName,
			HttpServletResponse resp) throws Exception {
		// 한글 깨짐 방지
		String downFile = URLEncoder.encode(oriFileName, "UTF-8");

		File file = new File(path);

		InputStream is = new FileInputStream(file);
		resp.setContentType("application/octet-stream");
		resp.setHeader("content-Disposition", "attachment; filename=\"" + downFile + "\"");
		// filename="파일이름.txt"

		OutputStream os = resp.getOutputStream();

		// 출력은 바이트 단위로
		byte[] buffer = new byte[1024];
		int length;
		while ((length = is.read(buffer)) != -1) {
			os.write(buffer, 0, length);
		}

		os.flush();
		os.close();
		is.close();
	}

	public boolean upFile(MultipartHttpServletRequest multi, int cnum, int cate) {
		// 파일을 저장할 절대 경로 찾기
		String root = "C:/Users/78/eclipse-workspace-ifn/Last_Final/src/main/webapp/";
		String path = root + "resources/file/";
		// 폴더 생성
		File dir = new File(path);
		if (!dir.isDirectory()) {
			dir.mkdir();
		}
		// 파일이 2개 이상일 때
		Iterator<String> files = multi.getFileNames();
		Map<String, String> fMap = new HashMap<String, String>();
		// 글번호를 map에 저장
		fMap.put("cnum", String.valueOf(cnum));
		boolean f = false;

		// 파일을 여러개 처리해야 하기 때문에 반복
		while (files.hasNext()) {
			String fileName = files.next();

			MultipartFile mf = multi.getFile(fileName);
			// 원래 파일 이름
			String oriName = mf.getOriginalFilename();
			fMap.put("oriFileName", oriName);
			// a.txt
			// 실제 저장할 파일 이름 생성
			String sysName = System.currentTimeMillis() + oriName.substring(oriName.lastIndexOf("."));
			// 1123234354.txt
			fMap.put("sysFileName", sysName);

			try {
				mf.transferTo(new File(path + sysName));
				// 파일 데이터 저장
				//Free
				if(cate==1) {
					f = cDao.CommuFreefileInsert(fMap);
				}
				//Complan
				if(cate==2) {
					f = cDao.CommuComplanfileInsert(fMap); 
				}
							
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		return f;
	}
	
	public boolean upMemFile(MultipartHttpServletRequest multi, String mid) {
		//파일을 저장할 절대 경로 찾기
		String root = "C:/Users/78/eclipse-workspace-ifn/Last_Final/src/main/webapp/";
		String path = root + "resources/files/";

		//폴더 생성
		File dir = new File(path);
		if(!dir.isDirectory()) {
			dir.mkdir();
		}

		//파일이 2개 이상일 때
		Iterator<String> files = multi.getFileNames();

		Map<String, String> fMap = new HashMap<String, String>();

		//아이디를 map에 저장
		fMap.put("m_id", String.valueOf(mid));

		boolean f = false;

		//파일을 여러개 처리해야 하기 때문에 반복
		while(files.hasNext()) {
			String fileName = files.next();

			MultipartFile mf = multi.getFile(fileName);
			//원래 파일 이름
			String oriName = mf.getOriginalFilename();
			fMap.put("oriFileName", oriName);
			//a.txt
			//실제 저장할 파일 이름 생성
			String sysName = System.currentTimeMillis()
					+ oriName.substring
					(oriName.lastIndexOf("."));
			//1123234354.txt
			fMap.put("sysFileName", sysName);

			try {
				mf.transferTo(new File(path + sysName));
				//파일 데이터 저장
				f = ifDao.fileInsert(fMap);
			}catch(IOException e) {
				e.printStackTrace();
			}
		}

		return f;
	}

	public boolean upCarFile(MultipartHttpServletRequest multi, String number) {
	      //파일을 저장할 절대 경로 찾기
	      String root = "C:/Users/78/eclipse-workspace-ifn/Last_Final/src/main/webapp/";
	      String path = root + "resources/carfiles/";

	      //폴더 생성
	      File dir = new File(path);
	      if(!dir.isDirectory()) {
	         dir.mkdir();
	      }

	      //파일이 2개 이상일 때
	      Iterator<String> files = multi.getFileNames();

	      Map<String, String> fMap = new HashMap<String, String>();

	      //아이디를 map에 저장
	      fMap.put("m_id", String.valueOf(number));

	      boolean f = false;

	      //파일을 여러개 처리해야 하기 때문에 반복
	      while(files.hasNext()) {
	         String fileName = files.next();

	         MultipartFile mf = multi.getFile(fileName);
	         //원래 파일 이름
	         String oriName = mf.getOriginalFilename();
	         fMap.put("oriFileName", oriName);
	         //a.txt
	         //실제 저장할 파일 이름 생성
	         String sysName = System.currentTimeMillis()
	               + oriName.substring
	               (oriName.lastIndexOf("."));
	         //1123234354.txt
	         fMap.put("sysFileName", sysName);

	         try {
	            mf.transferTo(new File(path + sysName));
	            //파일 데이터 저장
	            f = ifDao.KRfileInsert(fMap);
	         }catch(IOException e) {
	            e.printStackTrace();
	         }
	      }

	      return f;
	   }
	public boolean upFCarFile(MultipartHttpServletRequest multi, String number) {
        //파일을 저장할 절대 경로 찾기
        String root = "D:/Eclipse/workspace-jsp/Last_Final/src/main/webapp/";
        String path = root + "resources/carfiles/";

        //폴더 생성
        File dir = new File(path);
        if(!dir.isDirectory()) {
           dir.mkdir();
        }

        //파일이 2개 이상일 때
        Iterator<String> files = multi.getFileNames();

        Map<String, String> fMap = new HashMap<String, String>();

        //아이디를 map에 저장
        fMap.put("m_id", String.valueOf(number));

        boolean f = false;

        //파일을 여러개 처리해야 하기 때문에 반복
        while(files.hasNext()) {
           String fileName = files.next();

           MultipartFile mf = multi.getFile(fileName);
           //원래 파일 이름
           String oriName = mf.getOriginalFilename();
           fMap.put("oriFileName", oriName);
           //a.txt
           //실제 저장할 파일 이름 생성
           String sysName = System.currentTimeMillis()
                 + oriName.substring
                 (oriName.lastIndexOf("."));
           //1123234354.txt
           fMap.put("sysFileName", sysName);

           try {
              mf.transferTo(new File(path + sysName));
              //파일 데이터 저장
              f = ifDao.FRfileInsert(fMap);
           }catch(IOException e) {
              e.printStackTrace();
           }
        }

        return f;
     }




}
