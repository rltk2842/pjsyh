package com.hdh.lastfinal;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hdh.lastfinal.bean.Member;
import com.hdh.lastfinal.bean.sellinfo;
import com.hdh.lastfinal.dao.IMemberDao;
import com.hdh.lastfinal.service.CarManagement;
import com.hdh.lastfinal.service.MemberManagement;

@Controller
public class MyPageController {

	@Autowired
	private JavaMailSender mailSender;


	@Autowired
	private IMemberDao mbDao;


	ModelAndView mav;

	@Autowired
	MemberManagement mbm;//Service 클래스를 찾아서 객체 생성
	
	@Autowired
	CarManagement cam;//Service 클래스를 찾아서 객체 생성


	@Autowired
	HttpSession session;


	@RequestMapping(value = "/MyPage", method = RequestMethod.GET)
	public ModelAndView MyPageList(Member mb) {


		mav = mbm.MyPageList(mb);

		return mav;
	}

	//회원 블락 페이지
	@RequestMapping(value = "/MemBlock", method = RequestMethod.GET)
	public ModelAndView MemBlock(Integer pageNum) {

		mav = mbm.memberSearch(pageNum);

		return mav;
	}

	

	//회원 수정
	@RequestMapping(value = "/MemUpdateList", method = RequestMethod.GET)
	public ModelAndView MemUpdateList(Member mb) {


		mav = mbm.MemUpdateList(mb);

		return mav;
	}

	//일반으로 전환
	@RequestMapping(value = "/memGeneral", method = RequestMethod.GET)
	public ModelAndView memGeneral(HttpServletRequest request,Member mb) {

		String id = request.getParameter("m_id");
		System.out.println(id);

		mav = mbm.memGeneral(request, mb);

		return mav;
	}

	//딜러로 전환
	@RequestMapping(value = "/memDealer", method = RequestMethod.GET)
	public ModelAndView memDealer(HttpServletRequest request,Member mb) {

		String id = request.getParameter("m_id");
		System.out.println(id);

		mav = mbm.memDealer(request, mb);

		return mav;

	}

	//블락으로 전환
	@RequestMapping(value = "/memBlock", method = RequestMethod.GET)
	public ModelAndView memBlock(HttpServletRequest request,Member mb) {

		String id = request.getParameter("m_id");

		mav = mbm.memBlock(request, mb);

		return mav;

	}


	//회원 수정
	@RequestMapping(value = "/MemUpdate", method = RequestMethod.POST)
	public ModelAndView memberUpdate(Member mb) {

		mav = mbm.memberUpdate(mb);

		return mav;
	}

	//새 비밀번호 UpdatePW
	@RequestMapping(value = "/UpdatePW", method = RequestMethod.POST)
	public ModelAndView UpdatePW(Member mb) {

		mav = mbm.UpdatePW(mb);

		return mav;
	}

	//판매 차량
	@RequestMapping(value = "/PurCar", method = RequestMethod.GET)
	public ModelAndView PurCar(sellinfo se) {
		
		

		mav = cam.PurCarList(se);
		
		return mav; 
	}
	
	
	//구매 차량
		@RequestMapping(value = "/PurManage", method = RequestMethod.GET)
		public ModelAndView CarManage(sellinfo se) {


			mav = cam.PurManage(se);
			
			return mav; 
		}
	

}
