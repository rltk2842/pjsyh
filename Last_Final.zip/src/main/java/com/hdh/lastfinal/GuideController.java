package com.hdh.lastfinal;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class GuideController {
	@RequestMapping(value = "/GuideHome", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		
		return "/Guide/GuideHome";
	}
	@RequestMapping(value = "/buyGuide", method = RequestMethod.GET)
	public ModelAndView buyGuide(Locale locale, Model model) {
		ModelAndView mav = new ModelAndView();
		
		mav.setViewName("Guide/buyGuide");
	
		return mav;
	}
	@RequestMapping(value = "/longlenterGuide", method = RequestMethod.GET)
	public ModelAndView longlenterGuide(Locale locale, Model model) {
		ModelAndView mav = new ModelAndView();
		
		mav.setViewName("Guide/longlenterGuide");
	
		return mav;
	}
	@RequestMapping(value = "/buy1", method = RequestMethod.GET)
	public ModelAndView buy1(Locale locale, Model model) {
		ModelAndView mav = new ModelAndView();
		
		mav.setViewName("Guide/buy1");
	
		return mav;
	}
	@RequestMapping(value = "/buy2", method = RequestMethod.GET)
	public ModelAndView buy2(Locale locale, Model model) {
		ModelAndView mav = new ModelAndView();
		
		mav.setViewName("Guide/buy2");
	
		return mav;
	}
	@RequestMapping(value = "/buy3", method = RequestMethod.GET)
	public ModelAndView buy3(Locale locale, Model model) {
		ModelAndView mav = new ModelAndView();
		
		mav.setViewName("Guide/buy3");
	
		return mav;
	}
	@RequestMapping(value = "/long1", method = RequestMethod.GET)
	public ModelAndView long1(Locale locale, Model model) {
		ModelAndView mav = new ModelAndView();
		
		mav.setViewName("Guide/long1");
	
		return mav;
	}
	@RequestMapping(value = "/long2", method = RequestMethod.GET)
	public ModelAndView long2(Locale locale, Model model) {
		ModelAndView mav = new ModelAndView();
		
		mav.setViewName("Guide/long2");
	
		return mav;
	}
	@RequestMapping(value = "/long3", method = RequestMethod.GET)
	public ModelAndView long3(Locale locale, Model model) {
		ModelAndView mav = new ModelAndView();
		
		mav.setViewName("Guide/long3");
	
		return mav;
	}
}
